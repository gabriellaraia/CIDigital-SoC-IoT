`timescale 1ns/1ps
`default_nettype none

module tb_soc_uart;

////////////////////////////////////////////////////////////
// CLOCK 100 MHz
////////////////////////////////////////////////////////////
reg clk = 0;
always #5 clk = ~clk;   // 100 MHz

////////////////////////////////////////////////////////////
// RESET
////////////////////////////////////////////////////////////
reg aresetn = 0;
initial begin
    #100;
    aresetn = 1;
end

////////////////////////////////////////////////////////////
// BOOT
////////////////////////////////////////////////////////////
reg boot_pin = 1'b0;

////////////////////////////////////////////////////////////
// GPIO
////////////////////////////////////////////////////////////
reg  [4:0]  gpio_i = 0;
wire [29:0] gpio_o;

////////////////////////////////////////////////////////////
// UART
////////////////////////////////////////////////////////////
reg  uart_rx = 1'b1;
wire uart_tx;

////////////////////////////////////////////////////////////
// SPI / I2C / UNUSED
////////////////////////////////////////////////////////////
wire spi_csn;
wire spi_sclk;
wire spi_mosi;
reg  spi_miso = 1'b0;

wire spi_sclk_o;
wire spi_mosi_o;
reg  spi_miso_i = 1'b0;
wire spi_ss_n_o;

wire i2c_sda;
wire i2c_scl;

wire trap;

////////////////////////////////////////////////////////////
// DUT
////////////////////////////////////////////////////////////
soc_top #(
    .RAM_BYTES_REQ(64*1024)
) dut (
    .aclk(clk),
    .aresetn(aresetn),

    .boot_pin(boot_pin),

    .spi_csn(spi_csn),
    .spi_sclk(spi_sclk),
    .spi_mosi(spi_mosi),
    .spi_miso(spi_miso),

    .uart_rx(uart_rx),
    .uart_tx(uart_tx),

    .gpio_i(gpio_i),
    .gpio_o(gpio_o),

    .spi_sclk_o(spi_sclk_o),
    .spi_mosi_o(spi_mosi_o),
    .spi_miso_i(spi_miso_i),
    .spi_ss_n_o(spi_ss_n_o),

    .i2c_sda(i2c_sda),
    .i2c_scl(i2c_scl),

    .trap(trap)
);

////////////////////////////////////////////////////////////
// DEBUG CPU WRITE (AXI)
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (dut.cpu_awvalid && dut.cpu_awready &&
        dut.cpu_wvalid  && dut.cpu_wready) begin
        $display("CPU WRITE: ADDR=%h DATA=%h",
                  dut.cpu_awaddr,
                  dut.cpu_wdata);
    end
end

////////////////////////////////////////////////////////////
// UART MONITOR (BIT_DIV = 24)
// Decodifica a UART TX e imprime caracteres
////////////////////////////////////////////////////////////

localparam CLKS_PER_BIT = 24;

reg [3:0] bit_index;
reg [7:0] rx_shift;
reg receiving;
integer clk_count;
integer newline_count;

initial begin
    bit_index = 4'b0;
    rx_shift = 8'b0;
    receiving = 1'b0;
    clk_count = 0;
    newline_count = 0;
end

always @(posedge clk) begin

    if (!aresetn) begin
        receiving  <= 1'b0;
        clk_count  <= 0;
        bit_index  <= 4'b0;
        rx_shift   <= 8'b0;
        newline_count <= 0;
    end
    else begin

        // Detecta start bit (borda de descida em uart_tx)
        if (!receiving && uart_tx == 1'b0) begin
            receiving <= 1'b1;
            clk_count <= CLKS_PER_BIT/2;
            bit_index <= 4'b0;
        end

        else if (receiving) begin

            if (clk_count == CLKS_PER_BIT-1) begin
                clk_count <= 0;
                bit_index <= bit_index + 1;

                // Bits 1..8 = dados (LSB first)
                if (bit_index >= 4'd1 && bit_index <= 4'd8) begin
                    rx_shift <= {rx_shift[6:0], uart_tx};
                end

                // Stop bit (bit_index == 9)
                if (bit_index == 4'd9) begin
                    receiving <= 1'b0;

                    // Imprime o caractere recebido
                    $write("%c", rx_shift);
                    //$fflush();
                    //$stop;

                    // Detecta newline (0x0A)
                    if (rx_shift == 8'h0A) begin
                        newline_count <= newline_count + 1;
                        $display("");
                        $display("===== UART MESSAGE END (msg %d) =====", newline_count);
                    end
                end

            end
            else begin
                clk_count <= clk_count + 1;
            end
        end
    end
end

////////////////////////////////////////////////////////////
// MONITOR DE TRAP
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (trap) begin
        $display("CPU entrou em TRAP!");
        $stop;
    end
end

////////////////////////////////////////////////////////////
// TIMEOUT (10 ms @ 100MHz)
////////////////////////////////////////////////////////////

initial begin
    #10_000_000;
    $display("===== TIMEOUT =====");
    $stop;
end


endmodule