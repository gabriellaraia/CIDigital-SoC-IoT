#include <stdint.h>

// =====================================================================
// SoC Address Map
// =====================================================================
#define AXI_UART_BASE           0x40002000

// UART Lite Registers (offsets)
#define UART_RX_OFFSET          0x00
#define UART_TX_OFFSET          0x04
#define UART_STATUS_OFFSET      0x08

// UART Status Register Bits
#define UART_STATUS_RXVALID     (1 << 0)   // RX FIFO has data
#define UART_STATUS_RXFULL      (1 << 1)   // RX FIFO is full
#define UART_STATUS_TXEMPTY     (1 << 2)   // TX FIFO is empty
#define UART_STATUS_TXFULL      (1 << 3)   // TX FIFO is full
#define UART_STATUS_IE          (1 << 4)   // Interrupt enable

// =====================================================================
// Helper Macros
// =====================================================================
#define UART_REG(offset) (*(volatile uint32_t *)(AXI_UART_BASE + offset))

// =====================================================================
// UART Functions
// =====================================================================

/**
 * @brief Wait until UART TX is ready (FIFO not full)
 */
void uart_wait_tx_ready(void) {
    while (UART_REG(UART_STATUS_OFFSET) & UART_STATUS_TXFULL) {
        // Busy wait until TX FIFO has space
    }
}

/**
 * @brief Send a single character via UART
 * @param c Character to send (8-bit)
 */
void uart_putchar(char c) {
    uart_wait_tx_ready();
    UART_REG(UART_TX_OFFSET) = (uint32_t)c;
}

/**
 * @brief Send a string via UART
 * @param str Null-terminated string pointer
 */
void uart_puts(const char *str) {
    while (*str) {
        uart_putchar(*str);
        str++;
    }
}

// =====================================================================
// Main Program
// =====================================================================
int main(void) {
    // Send a single character 'A' (0x41)
    uart_putchar('A');
    
    // Send a newline
    uart_putchar('\n');
    
    // Infinite loop (or return 0 if you prefer)
    while (1) {
        // Can add more functionality here
    }
    
    return 0;
}