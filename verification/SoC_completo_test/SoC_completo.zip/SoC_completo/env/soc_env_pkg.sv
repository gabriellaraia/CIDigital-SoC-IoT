// =========================================================================
// Arquivo: env/soc_env_pkg.sv
// Descrição: Pacote do Ambiente. Agrupa as classes da camada ENV para
//            facilitar a compilação e importação no Top Level / Testes.
// =========================================================================

package soc_env_pkg;

    // 1. Importação fundamental do UVM
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // 2. Importação dos pacotes dos Agentes 
    // (Assumindo que futuramente empacotaremos as pastas dos agentes também,
    //  ou podemos incluir os arquivos .sv dos agentes diretamente aqui)
    import axi_lite_agent_pkg::*;
    import gpio_agent_pkg::*;
    import uart_agent_pkg::*;
    import spi_agent_pkg::*;
    import i2c_agent_pkg::*;
    

    // 3. Inclusão dos componentes do Ambiente na ordem correta de dependência!
    // O Virtual Sequencer e o Scoreboard não dependem do soc_env, 
    // mas o soc_env depende deles. Logo, eles vêm primeiro.
    
    `include "soc_virtual_sequencer.sv"
    `include "soc_scoreboard.sv"
    `include "soc_env.sv"

endpackage