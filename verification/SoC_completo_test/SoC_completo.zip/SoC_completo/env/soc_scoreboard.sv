// =========================================================================
// Arquivo: env/soc_scoreboard.sv
// Descrição: Compara as transações do barramento interno (AXI) com o 
//            comportamento físico dos periféricos (GPIO, UART, etc).
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

//  ou podemos incluir os arquivos .sv dos agentes diretamente aqui)
    import axi_lite_agent_pkg::*;
    import gpio_agent_pkg::*;
    import uart_agent_pkg::*;
    import spi_agent_pkg::*;
    import i2c_agent_pkg::*;
    

class soc_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(soc_scoreboard)

    // -------------------------------------------------------------------------
    // 1. FIFOs de Análise (Buffers para receber dados dos Monitores)
    // Nota: No soc_env.sv nós conectamos os monitores diretamente nestas FIFOs.
    // Ex: axi_agt.monitor.item_collected_port.connect(scb.axi_export.analysis_export);
    // -------------------------------------------------------------------------
    uvm_tlm_analysis_fifo #(axi_lite_seq_item) axi_export;
    uvm_tlm_analysis_fifo #(gpio_seq_item)     gpio_export;
    uvm_tlm_analysis_fifo #(uart_seq_item)     uart_export;
    uvm_tlm_analysis_fifo #(spi_seq_item)      spi_export;
    uvm_tlm_analysis_fifo #(i2c_seq_item)      i2c_export;

    // Endereços Base (Memory Map do seu SoC)
    localparam bit [31:0] GPIO_BASE_ADDR = 32'h4000_0000;
    localparam bit [31:0] UART_BASE_ADDR = 32'h4000_2000;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção: Instanciando as FIFOs
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        axi_export  = new("axi_export", this);
        gpio_export = new("gpio_export", this);
        uart_export = new("uart_export", this);
        spi_export  = new("spi_export", this);
        i2c_export  = new("i2c_export", this);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Execução: Onde a inteligência reside
    // -------------------------------------------------------------------------
    task run_phase(uvm_phase phase);
        // Rodamos as threads de verificação em paralelo
        fork
            check_gpio_logic();
            // check_uart_logic(); // Futuras threads para outros periféricos
            // check_spi_logic();
        join
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Lógica de Verificação do GPIO
    // -------------------------------------------------------------------------
    task check_gpio_logic();
        axi_lite_seq_item axi_trx;
        gpio_seq_item     gpio_trx;
        
        bit [29:0] expected_gpio_out = 0; // O estado esperado dos LEDs

        // Thread 1: Atualiza o modelo esperado com base no barramento AXI
        fork
            forever begin
                axi_export.get(axi_trx);
                if (axi_trx.rnw == 1'b0 && (axi_trx.addr & 32'hFFFF_0000) == GPIO_BASE_ADDR) begin
                    expected_gpio_out = axi_trx.data[29:0];
                end
            end
            
        // Thread 2: Compara as mudanças físicas com o modelo esperado
            forever begin
                gpio_export.get(gpio_trx);
                // Quando o pino físico muda, o valor deve bater com o que o AXI mandou
                if (gpio_trx.gpio_o === expected_gpio_out) begin
                    `uvm_info("SCB_PASS", $sformatf("GPIO Match!"), UVM_LOW)
                end else begin
                    `uvm_error("SCB_FAIL", $sformatf("Erro! GPIO fisico mudou para %0h, mas esperado era %0h", gpio_trx.gpio_o, expected_gpio_out))
                end
            end
        join
    endtask

endclass