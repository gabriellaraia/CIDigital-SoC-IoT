// =========================================================================
// Arquivo: env/soc_virtual_sequencer.sv
// Descrição: O Maestro do ambiente. Contém ponteiros para os sequencers físicos
//            para permitir a criação de sequências complexas (Virtual Sequences).
// =========================================================================

import uvm_pkg::*;
`include "uvm_macros.svh"

//  ou podemos incluir os arquivos .sv dos agentes diretamente aqui)
    import axi_lite_agent_pkg::*;
    import gpio_agent_pkg::*;
    import uart_agent_pkg::*;
    import spi_agent_pkg::*;
    import i2c_agent_pkg::*;
    

class soc_virtual_sequencer extends uvm_sequencer;
    `uvm_component_utils(soc_virtual_sequencer)

    // -------------------------------------------------------------------------
    // Ponteiros (Handles) para os sequencers físicos dos Agentes
    // -------------------------------------------------------------------------
    axi_lite_sequencer axi_sqr;
    gpio_sequencer     gpio_sqr;
    uart_sequencer     uart_sqr;
    spi_sequencer      spi_sqr;
    i2c_sequencer      i2c_sqr;

    // Construtor padrão do UVM
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // Nota: Um Virtual Sequencer geralmente não precisa de build_phase 
    // ou run_phase. Ele é apenas um contêiner estrutural de roteamento.

endclass