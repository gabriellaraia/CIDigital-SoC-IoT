// =========================================================================
// Arquivo: env/soc_env.sv
// Descrição: Ambiente UVM principal. Agrupa e conecta todos os componentes.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

// Importação dos pacotes necessários para reconhecer os tipos de agentes e sequencers
import axi_lite_agent_pkg::*;
import gpio_agent_pkg::*;
import uart_agent_pkg::*;
import spi_agent_pkg::*;
import i2c_agent_pkg::*;

class soc_env extends uvm_env;
    `uvm_component_utils(soc_env)

    // -------------------------------------------------------------------------
    // 1. Declaração dos Componentes
    // -------------------------------------------------------------------------
    // Nossos Agentes (Agora reconhecidos através dos pacotes importados)
    axi_lite_agent axi_agt;
    gpio_agent     gpio_agt;
    uart_agent     uart_agt;
    spi_agent      spi_agt;
    i2c_agent      i2c_agt;

    // Componentes de Inteligência
    soc_scoreboard        scb;
    soc_virtual_sequencer vsqr;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        // Instanciando os 5 Agentes via Factory
        axi_agt  = axi_lite_agent::type_id::create("axi_agt", this);
        gpio_agt = gpio_agent::type_id::create("gpio_agt", this);
        uart_agt = uart_agent::type_id::create("uart_agt", this);
        spi_agt  = spi_agent::type_id::create("spi_agt", this);
        i2c_agt  = i2c_agent::type_id::create("i2c_agt", this);

        // Instanciando o Scoreboard e o Virtual Sequencer
        scb  = soc_scoreboard::type_id::create("scb", this);
        vsqr = soc_virtual_sequencer::type_id::create("vsqr", this);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        // A. Conectando os Monitores às FIFOs do Scoreboard
        // O sufixo .analysis_export é obrigatório para acessar a porta de entrada da FIFO [cite: 389]
        axi_agt.monitor.item_collected_port.connect(scb.axi_export.analysis_export);
        gpio_agt.monitor.item_collected_port.connect(scb.gpio_export.analysis_export);
        uart_agt.monitor.item_collected_port.connect(scb.uart_export.analysis_export);
        spi_agt.monitor.item_collected_port.connect(scb.spi_export.analysis_export);
        i2c_agt.monitor.item_collected_port.connect(scb.i2c_export.analysis_export);

        // B. Conectando os Sequencers Físicos ao Virtual Sequencer (O Maestro)
        // Este bloco garante que o Virtual Sequencer tenha handles para os sequencers físicos [cite: 390]
        if (axi_agt.get_is_active() == UVM_ACTIVE)
            vsqr.axi_sqr = axi_agt.sequencer;
            
        if (gpio_agt.get_is_active() == UVM_ACTIVE)
            vsqr.gpio_sqr = gpio_agt.sequencer;
            
        if (uart_agt.get_is_active() == UVM_ACTIVE)
            vsqr.uart_sqr = uart_agt.sequencer;
            
        if (spi_agt.get_is_active() == UVM_ACTIVE)
            vsqr.spi_sqr = spi_agt.sequencer;
            
        if (i2c_agt.get_is_active() == UVM_ACTIVE)
            vsqr.i2c_sqr = i2c_agt.sequencer;
            
    endfunction

endclass