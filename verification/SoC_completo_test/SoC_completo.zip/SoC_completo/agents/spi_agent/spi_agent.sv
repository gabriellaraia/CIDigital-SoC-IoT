// =========================================================================
// Arquivo: agents/spi_agent/spi_agent.sv
// Descrição: Agente UVM completo para a interface SPI (Atua como Slave).
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

class spi_agent extends uvm_agent;
    `uvm_component_utils(spi_agent)

    // Instâncias dos componentes internos
    spi_driver    driver;
    spi_monitor   monitor;
    spi_sequencer sequencer;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        // O Monitor escuta os pinos MISO, MOSI, SCLK e SS_N
        monitor = spi_monitor::type_id::create("monitor", this);

        // Se ativo, constrói quem responde ao Mestre do SoC
        if (get_is_active() == UVM_ACTIVE) begin
            driver    = spi_driver::type_id::create("driver", this);
            sequencer = spi_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        if (get_is_active() == UVM_ACTIVE) begin
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass