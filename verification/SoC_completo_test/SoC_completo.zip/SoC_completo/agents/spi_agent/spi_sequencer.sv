// =========================================================================
// Arquivo: agents/spi_agent/spi_sequencer.sv
// Descrição: Sequencer UVM para a interface SPI.
// =========================================================================

import uvm_pkg::*;
`include "uvm_macros.svh"

class spi_sequencer extends uvm_sequencer #(spi_seq_item);
    `uvm_component_utils(spi_sequencer)

    // Construtor padrão do UVM
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

endclass