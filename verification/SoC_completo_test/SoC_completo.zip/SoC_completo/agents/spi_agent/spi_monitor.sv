import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class spi_monitor extends uvm_monitor;
    `uvm_component_utils(spi_monitor)
    
    v_spi_if_t vif; // Usa o tipo padronizado
    uvm_analysis_port #(spi_seq_item) item_collected_port;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        item_collected_port = new("item_collected_port", this);
    endfunction

    // ADICIONADA: Build phase para capturar a interface
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_spi_if_t)::get(this, "", "vif_spi", vif))
            `uvm_fatal("NO_VIF", "Monitor SPI nao encontrou a interface 'vif_spi'")
    endfunction

    task run_phase(uvm_phase phase);
        spi_seq_item trans;
        forever begin
            wait(vif.ss_n == 1'b0);
            trans = spi_seq_item::type_id::create("trans");

            for (int i = 7; i >= 0; i--) begin
                @(posedge vif.sclk);
                trans.data_mosi[i] = vif.mosi;
                trans.data_miso[i] = vif.miso;
            end

            wait(vif.ss_n == 1'b1);
            item_collected_port.write(trans);
        end
    endtask
endclass