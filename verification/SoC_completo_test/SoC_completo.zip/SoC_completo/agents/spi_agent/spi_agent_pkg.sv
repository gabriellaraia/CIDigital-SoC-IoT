import uvm_pkg::*;
`include "uvm_macros.svh"

package spi_agent_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // Como este arquivo está na MESMA pasta que as classes abaixo, 
    // nenhum Include Directory precisa ser configurado no Vivado!
    `include "spi_seq_item.sv"
    `include "spi_sequencer.sv"
    `include "spi_driver.sv"
    `include "spi_monitor.sv"
    `include "spi_agent.sv"
endpackage