import uvm_pkg::*;
`include "uvm_macros.svh"

import uvm_pkg::*;
`include "uvm_macros.svh"

class spi_seq_item extends uvm_sequence_item;
    // Dado que o Agente (Slave) vai enviar para o SoC (MISO)
    rand bit [7:0] data_miso;

    // Dado que o SoC (Master) enviou para o Agente (MOSI) - preenchido pelo Monitor/Driver
    bit [7:0] data_mosi;

    `uvm_object_utils_begin(spi_seq_item)
        `uvm_field_int(data_miso, UVM_ALL_ON)
        `uvm_field_int(data_mosi, UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "spi_seq_item");
        super.new(name);
    endfunction
endclass