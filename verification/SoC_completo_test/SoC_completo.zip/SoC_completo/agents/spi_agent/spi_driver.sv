import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*;

class spi_driver extends uvm_driver #(spi_seq_item);
    `uvm_component_utils(spi_driver)
    
    v_spi_if_t vif; // Usa o tipo padronizado
    bit has_valid_req;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_spi_if_t)::get(this, "", "vif_spi", vif))
            `uvm_fatal("NO_VIF", "Driver SPI nao encontrou a interface")
    endfunction

    task run_phase(uvm_phase phase);
        vif.miso <= 1'b0;

        forever begin
            has_valid_req = 1'b0;

            // 1. PRIMEIRO: Aguarda o SoC selecionar este escravo
            wait(vif.ss_n == 1'b0);

            // 2. Tenta pegar a resposta do sequencer (Não bloqueante)
            seq_item_port.try_next_item(req);
            
            if (req != null) begin
                has_valid_req = 1'b1;
            end else begin
                // Cria um dado dummy (ex: 0xAA) se não houver sequência ativa
                req = spi_seq_item::type_id::create("dummy_req");
                req.data_miso = 8'hAA; 
            end

            // 3. Conduz o PRIMEIRO bit (MSB) imediatamente (SPI Mode 0)
            vif.miso <= req.data_miso[7];

            // 4. Conduz os 7 bits restantes nas bordas de descida
            for (int i = 6; i >= 0; i--) begin
                @(negedge vif.sclk);
                vif.miso <= req.data_miso[i];
            end

            // Aguarda o fim da transmissão
            wait(vif.ss_n == 1'b1);
            
            // Só avisa o sequencer se realmente processou um item dele
            if (has_valid_req) begin
                seq_item_port.item_done();
            end
        end
    endtask
endclass