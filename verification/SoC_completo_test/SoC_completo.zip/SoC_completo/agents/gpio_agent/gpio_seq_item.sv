import uvm_pkg::*;
`include "uvm_macros.svh"

class gpio_seq_item extends uvm_sequence_item;

    // Estímulo 
    rand bit [4:0]  gpio_i; // 5 botões/chaves

    // Resposta 
    bit [29:0]      gpio_o; // 30 LEDs/atuadores

    // Registro na Factory
    `uvm_object_utils_begin(gpio_seq_item)
        `uvm_field_int(gpio_i, UVM_ALL_ON)
        `uvm_field_int(gpio_o, UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "gpio_seq_item");
        super.new(name);
    endfunction

endclass