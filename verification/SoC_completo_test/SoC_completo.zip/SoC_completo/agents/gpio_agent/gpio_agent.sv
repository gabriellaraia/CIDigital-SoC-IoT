// =========================================================================
// Arquivo: agents/gpio_agent/gpio_agent.sv
// Descrição: Agente UVM completo para a interface GPIO.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
class gpio_agent extends uvm_agent;
    `uvm_component_utils(gpio_agent)

    // Instâncias dos componentes internos
    gpio_driver    driver;
    gpio_monitor   monitor;
    gpio_sequencer sequencer;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        // O Monitor é instanciado sempre, pois precisamos sempre ler os LEDs
        monitor = gpio_monitor::type_id::create("monitor", this);

        // Se o agente estiver configurado como ATIVO, construímos quem gera estímulos
        if (get_is_active() == UVM_ACTIVE) begin
            driver    = gpio_driver::type_id::create("driver", this);
            sequencer = gpio_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        // Conecta a porta do Driver à exportação do Sequencer (se ativo)
        if (get_is_active() == UVM_ACTIVE) begin
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass