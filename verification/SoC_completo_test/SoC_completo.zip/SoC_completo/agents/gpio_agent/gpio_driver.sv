import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class gpio_driver extends uvm_driver #(gpio_seq_item);
    `uvm_component_utils(gpio_driver)

    virtual gpio_if vif;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual gpio_if#(5,30))::get(this, "", "vif_gpio", vif)) begin
            `uvm_fatal("NO_VIF", "Driver GPIO nao encontrou a interface virtual 'vif_gpio'")
        end
    endfunction

    task run_phase(uvm_phase phase);
        // Garante que as entradas comecem zeradas
        vif.gpio_i = 5'b0; 

        forever begin
            seq_item_port.get_next_item(req);
            
            // Aplica o valor desejado aos pinos físicos
            vif.gpio_i = req.gpio_i;
            
            // Como é um sinal assíncrono, esperamos apenas 1 ciclo de clock
            // para garantir que o nível lógico estabilizou no hardware
            @(posedge vif.clk); // Assumindo que você adicione um 'clk' na interface, ou use um delay #10
            
            seq_item_port.item_done();
        end
    endtask
endclass