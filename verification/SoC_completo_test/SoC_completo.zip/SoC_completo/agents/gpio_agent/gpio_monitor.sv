import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class gpio_monitor extends uvm_monitor;
    `uvm_component_utils(gpio_monitor)

    virtual gpio_if vif;
    uvm_analysis_port #(gpio_seq_item) item_collected_port;

    // Variáveis para guardar o estado anterior e detectar mudanças
    logic [4:0]  last_gpio_i;
    logic [29:0] last_gpio_o;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual gpio_if#(5,30))::get(this, "", "vif_gpio", vif)) begin
            `uvm_fatal("NO_VIF", "Monitor GPIO nao encontrou a interface virtual")
        end
    endfunction

    task run_phase(uvm_phase phase);
        // Inicializa com os valores atuais da placa
        last_gpio_i = vif.gpio_i;
        last_gpio_o = vif.gpio_o;

        forever begin
            // Fica bloqueado aqui até que algum pino mude de estado
            @(vif.gpio_i or vif.gpio_o);

            // Um pequeno delay para evitar capturar "glitches" (ruídos) 
            // de transição do SystemVerilog em delta-cycles
            #1ps; 

            // Se o valor realmente mudou em relação ao estado anterior
            if (vif.gpio_i !== last_gpio_i || vif.gpio_o !== last_gpio_o) begin
                gpio_seq_item trans = gpio_seq_item::type_id::create("trans");
                
                // Tira a foto do estado atual
                trans.gpio_i = vif.gpio_i;
                trans.gpio_o = vif.gpio_o;
                
                // Envia para o Scoreboard
                item_collected_port.write(trans);
                
                // Atualiza o estado anterior
                last_gpio_i = vif.gpio_i;
                last_gpio_o = vif.gpio_o;
            end
        end
    endtask
endclass