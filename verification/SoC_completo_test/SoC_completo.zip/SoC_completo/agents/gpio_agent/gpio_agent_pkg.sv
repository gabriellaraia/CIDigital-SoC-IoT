package gpio_agent_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // Como este arquivo está na MESMA pasta que as classes abaixo, 
    // nenhum Include Directory precisa ser configurado no Vivado!
    `include "gpio_seq_item.sv"
    `include "gpio_sequencer.sv"
    `include "gpio_driver.sv"
    `include "gpio_monitor.sv"
    `include "gpio_agent.sv"
endpackage