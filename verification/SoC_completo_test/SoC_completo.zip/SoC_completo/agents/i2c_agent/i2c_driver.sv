// =========================================================================
// Arquivo: agents/i2c_agent/i2c_driver.sv
// Descrição: Driver UVM Escravo Reativo corrigido.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
import soc_types_pkg::*; 

class i2c_driver extends uvm_driver #(i2c_seq_item);
    `uvm_component_utils(i2c_driver)
    
    v_i2c_if_t vif; 

    // Endereço deste escravo virtual
    localparam bit [6:0] SLAVE_ADDR = 7'h5A;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_i2c_if_t)::get(this, "", "vif_i2c", vif))
            `uvm_fatal("NO_VIF", "Driver I2C nao encontrou a interface virtual")
    endfunction

    // CORREÇÃO: Atribuição bloqueante (=) e sinais 0/1 para evitar crash do XSim
    task drive_sda(bit val);
        if (val == 1'b0) begin
            vif.sda = 1'b0; // Puxa para 0
        end else begin
            vif.sda = 1'b1; // Puxa para 1 (Simula o pull-up)
        end
    endtask

    /*task run_phase(uvm_phase phase);
        bit [6:0] rx_addr;
        bit       rx_rnw;
        bit       has_valid_req; 

        // Inicializa soltando o barramento
        drive_sda(1'b1);

        forever begin
            has_valid_req = 1'b0;

            // 1. Aguarda START: SDA descendo com SCL alto
           // Workaround para evitar crash do Vivado (Substitui o 'iff')
        do begin
            @(negedge vif.sda);
        end while (vif.scl !== 1'b1);

            // 2. Lê endereço + R/W
            for (int i = 6; i >= 0; i--) begin
                @(posedge vif.scl);
                rx_addr[i] = vif.sda;
            end
            @(posedge vif.scl);
            rx_rnw = vif.sda;

            // 3. Verifica endereço
            if (rx_addr == SLAVE_ADDR) begin
                seq_item_port.try_next_item(req);
                
                if (req != null) begin
                    has_valid_req = 1'b1;
                end else begin // CORREÇÃO DE SINTAXE AQUI
                    req = i2c_seq_item::type_id::create("default_req");
                    req.data = 8'hFF; 
                end

                // Envia ACK do endereço
                @(negedge vif.scl);
                drive_sda(1'b0);
                @(negedge vif.scl);
                drive_sda(1'b1); 

                // 4. Processa Dados
                if (rx_rnw == 1'b0) begin
                    // Escrita do Master: Slave recebe
                    for (int i = 7; i >= 0; i--) begin
                        @(posedge vif.scl);
                        req.data[i] = vif.sda;
                    end
                    // Envia ACK do dado
                    @(negedge vif.scl);
                    drive_sda(1'b0);
                    @(negedge vif.scl); 
                    drive_sda(1'b1);
                end else begin
                    // Leitura do Master: Slave envia
                    for (int i = 7; i >= 0; i--) begin
                        @(negedge vif.scl);
                        drive_sda(req.data[i]);
                    end
                    // Libera SDA para ler o ACK do Master
                    @(negedge vif.scl);
                    drive_sda(1'b1);
                    @(posedge vif.scl); 
                    req.ack = vif.sda; 
                end
                
                // Aguarda STOP: SDA subindo com SCL alto
                // Workaround para o STOP
                do begin
                    @(posedge vif.sda);
                end while (vif.scl !== 1'b1);
                
                if (has_valid_req) begin
                    seq_item_port.item_done();
                end
            end
        end
    endtask*/

    task run_phase(uvm_phase phase);
        bit [6:0] rx_addr;
        bit       rx_rnw;
        bit       has_valid_req; 
        bit       scl_val;
        bit       sda_val;

        drive_sda(1'b1);

        while(1) begin
            has_valid_req = 1'b0;

            // Espera descida do SDA
            @(negedge vif.sda);
            scl_val = vif.scl;
            if (scl_val !== 1'b1) continue; // Volta ao inicio se nao for START

            for (int i = 6; i >= 0; i--) begin
                @(posedge vif.scl);
                sda_val = vif.sda;
                rx_addr[i] = sda_val;
            end
            
            @(posedge vif.scl);
            sda_val = vif.sda;
            rx_rnw = sda_val;

            if (rx_addr == SLAVE_ADDR) begin
                seq_item_port.try_next_item(req);
                if (req != null) begin
                    has_valid_req = 1'b1;
                end else begin
                    req = i2c_seq_item::type_id::create("default_req");
                    req.data = 8'hFF; 
                end

                @(negedge vif.scl);
                drive_sda(1'b0); 
                @(negedge vif.scl);
                drive_sda(1'b1); 

                if (rx_rnw == 1'b0) begin
                    for (int i = 7; i >= 0; i--) begin
                        @(posedge vif.scl);
                        sda_val = vif.sda;
                        req.data[i] = sda_val;
                    end
                    @(negedge vif.scl);
                    drive_sda(1'b0); 
                    @(negedge vif.scl); 
                    drive_sda(1'b1);
                end else begin
                    for (int i = 7; i >= 0; i--) begin
                        @(negedge vif.scl);
                        drive_sda(req.data[i]);
                    end
                    @(negedge vif.scl);
                    drive_sda(1'b1);
                    @(posedge vif.scl); 
                    sda_val = vif.sda;
                    req.ack = sda_val; 
                end
                
                // Espera subida do SDA
                @(posedge vif.sda);
                scl_val = vif.scl;
                if (scl_val === 1'b1) begin // É um STOP real
                    if (has_valid_req) seq_item_port.item_done();
                end
            end
        end
    endtask
endclass