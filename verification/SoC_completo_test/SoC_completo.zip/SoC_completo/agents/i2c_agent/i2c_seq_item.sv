// =========================================================================
// Arquivo: agents/i2c_agent/i2c_seq_item.sv
// Descrição: Define a transação (pacote de dados) para o barramento I2C.
// =========================================================================

import uvm_pkg::*;
`include "uvm_macros.svh"

class i2c_seq_item extends uvm_sequence_item;
    // -------------------------------------------------------------------------
    // Estímulos / Respostas
    // -------------------------------------------------------------------------
    rand bit [6:0] addr;     // Endereço do escravo (7 bits) [cite: 302, 303]
    rand bit [7:0] data;     // Dado a ser transmitido ou recebido [cite: 304]
    rand bit       rnw;      // 1 = Master Read (Slave envia), 0 = Master Write (Slave recebe) [cite: 305]
    
    bit            addr_ack; // NOVO: 0 = ACK do endereço (Sucesso), 1 = NACK (Falha)
    bit            ack;      // 0 = ACK do dado (Sucesso), 1 = NACK (Falha) [cite: 305, 306]

    // -------------------------------------------------------------------------
    // Registro na Factory
    // -------------------------------------------------------------------------
    `uvm_object_utils_begin(i2c_seq_item)
        `uvm_field_int(addr,     UVM_ALL_ON)
        `uvm_field_int(data,     UVM_ALL_ON)
        `uvm_field_int(rnw,      UVM_ALL_ON)
        `uvm_field_int(addr_ack, UVM_ALL_ON) // Campo adicionado para o log
        `uvm_field_int(ack,      UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "i2c_seq_item");
        super.new(name);
    endfunction
endclass