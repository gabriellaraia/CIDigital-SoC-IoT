// =========================================================================
// Arquivo: agents/i2c_agent/i2c_sequencer.sv
// Descrição: Sequencer UVM para a interface i2c.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
class i2c_sequencer extends uvm_sequencer #(i2c_seq_item);
    `uvm_component_utils(i2c_sequencer)

    // Construtor padrão do UVM
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

endclass