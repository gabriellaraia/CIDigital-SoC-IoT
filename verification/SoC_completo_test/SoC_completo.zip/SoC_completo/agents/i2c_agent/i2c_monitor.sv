// =========================================================================
// Arquivo: agents/i2c_agent/i2c_monitor.sv
// Descrição: Monitor UVM passivo para o barramento I2C.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
class i2c_monitor extends uvm_monitor;
    // CORREÇÃO: A macro deve estar DENTRO da classe e sem ponto e vírgula no final.
    `uvm_component_utils(i2c_monitor)
    
    // Importa os tipos necessários se não estiverem no pacote
    // import soc_types_pkg::*; 

    v_i2c_if_t vif; 
    uvm_analysis_port #(i2c_seq_item) item_collected_port;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_i2c_if_t)::get(this, "", "vif_i2c", vif))
            `uvm_fatal("NO_VIF", "Monitor I2C nao encontrou interface 'vif_i2c'")
    endfunction

    /*
    task run_phase(uvm_phase phase);
        i2c_seq_item trans;
        bit addr_ack_bit; 
        
        forever begin // <--- ESSA LINHA FALTAVA NO SEU CÓDIGO!
            // ==========================================
            // 1. Detecta START (Workaround anti-crash)
            // ==========================================
            do begin
                @(negedge vif.sda);
            end while (vif.scl !== 1'b1);
            
            trans = i2c_seq_item::type_id::create("trans");

            // Captura Endereço e R/W
            for (int i = 6; i >= 0; i--) begin
                @(posedge vif.scl);
                trans.addr[i] = vif.sda;
            end
            @(posedge vif.scl); 
            trans.rnw = vif.sda;

            // Captura ACK do endereço
            @(posedge vif.scl);
            addr_ack_bit = vif.sda; 
            trans.addr_ack = addr_ack_bit; 

            // Captura 1 Byte de Dado
            for (int i = 7; i >= 0; i--) begin
                @(posedge vif.scl);
                trans.data[i] = vif.sda;
            end

            // Captura ACK do dado
            @(posedge vif.scl);
            trans.ack = vif.sda;

            // ==========================================
            // 2. Detecta STOP (Workaround anti-crash)
            // ==========================================
            do begin
                @(posedge vif.sda);
            end while (vif.scl !== 1'b1);
            
            // Envia o pacote capturado
            item_collected_port.write(trans);
        end
    endtask */

    task run_phase(uvm_phase phase);
        i2c_seq_item trans;
        bit addr_ack_bit; 
        bit scl_val;
        bit sda_val;
        
        while(1) begin 
            @(negedge vif.sda);
            scl_val = vif.scl;
            if (scl_val !== 1'b1) continue;
            
            trans = i2c_seq_item::type_id::create("trans");

            for (int i = 6; i >= 0; i--) begin
                @(posedge vif.scl);
                sda_val = vif.sda;
                trans.addr[i] = sda_val;
            end
            
            @(posedge vif.scl); 
            sda_val = vif.sda;
            trans.rnw = sda_val;

            @(posedge vif.scl);
            sda_val = vif.sda;
            addr_ack_bit = sda_val; 
            trans.addr_ack = addr_ack_bit; 

            for (int i = 7; i >= 0; i--) begin
                @(posedge vif.scl);
                sda_val = vif.sda;
                trans.data[i] = sda_val;
            end

            @(posedge vif.scl);
            sda_val = vif.sda;
            trans.ack = sda_val;

            @(posedge vif.sda);
            scl_val = vif.scl;
            if (scl_val === 1'b1) begin
                item_collected_port.write(trans);
            end
        end
    endtask
endclass