// =========================================================================
// Arquivo: agents/i2c_agent/i2c_agent.sv
// Descrição: Agente UVM completo para a interface i2c (Atua como Slave).
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
class i2c_agent extends uvm_agent;
    `uvm_component_utils(i2c_agent)

    // Instâncias dos componentes internos
    i2c_driver    driver;
    i2c_monitor   monitor;
    i2c_sequencer sequencer;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        monitor = i2c_monitor::type_id::create("monitor", this);

        // Se ativo, constrói quem responde ao Mestre do SoC
        if (get_is_active() == UVM_ACTIVE) begin
            driver    = i2c_driver::type_id::create("driver", this);
            sequencer = i2c_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        if (get_is_active() == UVM_ACTIVE) begin
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass