import uvm_pkg::*;
`include "uvm_macros.svh"
package i2c_agent_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // Como este arquivo está na MESMA pasta que as classes abaixo, 
    // nenhum Include Directory precisa ser configurado no Vivado!
    `include "i2c_seq_item.sv"
    `include "i2c_sequencer.sv"
    `include "i2c_driver.sv"
    `include "i2c_monitor.sv"
    `include "i2c_agent.sv"
endpackage