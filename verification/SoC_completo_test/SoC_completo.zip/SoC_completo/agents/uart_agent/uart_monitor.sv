// =========================================================================
// Arquivo: agents/uart_agent/uart_monitor.sv
// Descrição: Escuta o pino TX, monta o byte e envia para o Scoreboard.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class uart_monitor extends uvm_monitor;
    `uvm_component_utils(uart_monitor)

    v_uart_if_t vif; // Usa o tipo padronizado
    uvm_analysis_port #(uart_seq_item) item_collected_port;

    time bit_period = 8680ns;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        item_collected_port = new("item_collected_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_uart_if_t)::get(this, "", "vif_uart", vif)) begin
            `uvm_fatal("NO_VIF", "Monitor UART nao encontrou a interface virtual 'vif_uart'")
        end
    endfunction

    task run_phase(uvm_phase phase);
        uart_seq_item trans;

        forever begin
            // 1. Aguarda a borda de descida (Início do START BIT)
            @(negedge vif.tx);

            // 2. Espera meio período para amostrar no centro do bit
            #(bit_period / 2);

            // Confirma se ainda é 0 (filtra ruídos super rápidos)
            if (vif.tx == 1'b0) begin
                trans = uart_seq_item::type_id::create("trans");

                // Pula para o centro do primeiro bit de dados
                #(bit_period);

                // 3. Lê os 8 bits de dados
                for (int i = 0; i < 8; i++) begin
                    trans.data[i] = vif.tx;
                    #(bit_period);
                end

                // 4. Verifica o STOP BIT
                if (vif.tx == 1'b0) begin
                    trans.framing_error = 1'b1; // Erro! Deveria ser 1
                end else begin
                    trans.framing_error = 1'b0;
                end

                // 5. Envia o pacote remontado para o Scoreboard
                item_collected_port.write(trans);
            end
        end
    endtask
endclass