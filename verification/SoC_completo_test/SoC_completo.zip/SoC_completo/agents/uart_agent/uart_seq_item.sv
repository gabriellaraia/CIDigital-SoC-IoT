// =========================================================================
// Arquivo: agents/uart_agent/uart_seq_item.sv
// Descrição: Pacote de dados para a interface UART (1 Byte de payload).
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

class uart_seq_item extends uvm_sequence_item;

    // O dado principal da UART (8 bits)
    rand bit [7:0] data;
    
    // Flags úteis para verificação avançada (opcional)
    bit parity_error;
    bit framing_error;

    // Registro na Factory
    `uvm_object_utils_begin(uart_seq_item)
        `uvm_field_int(data, UVM_ALL_ON)
        `uvm_field_int(parity_error, UVM_ALL_ON)
        `uvm_field_int(framing_error, UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "uart_seq_item");
        super.new(name);
    endfunction

endclass