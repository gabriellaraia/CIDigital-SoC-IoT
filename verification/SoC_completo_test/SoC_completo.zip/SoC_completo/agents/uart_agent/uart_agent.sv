// =========================================================================
// Arquivo: agents/uart_agent/uart_agent.sv
// Descrição: Agente UVM completo para a interface uart.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

class uart_agent extends uvm_agent;
    `uvm_component_utils(uart_agent)

    // Instâncias dos componentes internos
    uart_driver    driver;
    uart_monitor   monitor;
    uart_sequencer sequencer;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        monitor = uart_monitor::type_id::create("monitor", this);

        // Se o agente estiver configurado como ATIVO, construímos quem gera estímulos
        if (get_is_active() == UVM_ACTIVE) begin
            driver    = uart_driver::type_id::create("driver", this);
            sequencer = uart_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        // Conecta a porta do Driver à exportação do Sequencer (se ativo)
        if (get_is_active() == UVM_ACTIVE) begin
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass