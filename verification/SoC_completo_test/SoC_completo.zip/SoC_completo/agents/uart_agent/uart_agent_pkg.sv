package uart_agent_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // Como este arquivo está na MESMA pasta que as classes abaixo, 
    // nenhum Include Directory precisa ser configurado no Vivado!
    `include "uart_seq_item.sv"
    `include "uart_sequencer.sv"
    `include "uart_driver.sv"
    `include "uart_monitor.sv"
    `include "uart_agent.sv"
endpackage