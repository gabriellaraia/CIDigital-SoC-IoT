// =========================================================================
// Arquivo: agents/uart_agent/uart_driver.sv
// Descrição: Converte bytes do UVM em pulsos seriais no pino RX.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class uart_driver extends uvm_driver #(uart_seq_item);
    `uvm_component_utils(uart_driver)

    v_uart_if_t vif; // Usa o tipo padronizado

    time bit_period = 8680ns;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(v_uart_if_t)::get(this, "", "vif_uart", vif)) begin
            `uvm_fatal("NO_VIF", "Driver UART nao encontrou a interface virtual 'vif_uart'")
        end
    endfunction

    task run_phase(uvm_phase phase);
        // O estado de repouso (Idle) da UART é sempre nível ALTO (1)
        vif.rx = 1'b1;

        forever begin
            seq_item_port.get_next_item(req);

            // 1. Envia o START BIT (Nível Baixo)
            vif.rx = 1'b0;
            #(bit_period);

            // 2. Envia os 8 bits de DADOS (LSB primeiro)
            for (int i = 0; i < 8; i++) begin
                vif.rx = req.data[i];
                #(bit_period);
            end

            // 3. Envia o STOP BIT (Nível Alto)
            vif.rx = 1'b1;
            #(bit_period);

            // Transação finalizada
            seq_item_port.item_done();
        end
    endtask
endclass