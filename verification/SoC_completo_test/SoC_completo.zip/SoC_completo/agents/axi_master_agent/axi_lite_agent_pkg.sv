package axi_lite_agent_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    // Como este arquivo está na MESMA pasta que as classes abaixo, 
    // nenhum Include Directory precisa ser configurado no Vivado!
    `include "axi_lite_seq_item.sv"
    `include "axi_lite_sequencer.sv"
    `include "axi_lite_driver.sv"
    `include "axi_lite_monitor.sv"
    `include "axi_lite_agent.sv"
endpackage