// =========================================================================
// Arquivo: agents/axi_master_agent/axi_lite_sequencer.sv
// Descrição: Sequencer UVM para o barramento AXI4-Lite.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
class axi_lite_sequencer extends uvm_sequencer #(axi_lite_seq_item);
    `uvm_component_utils(axi_lite_sequencer)

    // Construtor padrão
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

endclass