// =========================================================================
// Arquivo: agents/axi_master_agent/axi_lite_agent.sv
// Descrição: Agente UVM completo para o barramento AXI4-Lite.
// =========================================================================

import uvm_pkg::*;
`include "uvm_macros.svh"

class axi_lite_agent extends uvm_agent;
    `uvm_component_utils(axi_lite_agent)

    // Instâncias dos componentes internos
    axi_lite_driver    driver;
    axi_lite_monitor   monitor;
    axi_lite_sequencer sequencer;

    // Construtor
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        // O Monitor é SEMPRE instanciado (seja modo Ativo ou Passivo)
        monitor = axi_lite_monitor::type_id::create("monitor", this);

        // O Driver e o Sequencer só são construídos se o agente for ATIVO
        if (get_is_active() == UVM_ACTIVE) begin
            driver    = axi_lite_driver::type_id::create("driver", this);
            sequencer = axi_lite_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Conexão (Connect Phase)
    // -------------------------------------------------------------------------
    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);

        // Se estivermos no modo Ativo, conectamos a porta de requisição
        // do Driver à porta de exportação do Sequencer.
        // É por este "tubo" que as transações fluem.
        if (get_is_active() == UVM_ACTIVE) begin
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass