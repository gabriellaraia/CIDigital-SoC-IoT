// =========================================================================
// Arquivo: agents/axi_master_agent/axi_lite_monitor.sv
// Descrição: Monitor UVM passivo para o barramento AXI4-Lite.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"
import soc_types_pkg::*; // Importa os tipos

class axi_lite_monitor extends uvm_monitor;
    `uvm_component_utils(axi_lite_monitor)

    // Interface virtual para ler os pinos físicos
    virtual axi_lite_if vif;

    // Porta de Análise (Analysis Port): O "alto-falante" do monitor.
    // É por aqui que ele envia as transações capturadas para o Scoreboard.
    uvm_analysis_port #(axi_lite_seq_item) item_collected_port;

    // -------------------------------------------------------------------------
    // Construtor
    // -------------------------------------------------------------------------
    function new(string name, uvm_component parent);
        super.new(name, parent);
        // Instancia a porta de análise
        item_collected_port = new("item_collected_port", this);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção: Buscar a interface no banco de dados
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual axi_lite_if)::get(this, "", "vif_axi", vif)) begin
            `uvm_fatal("NO_VIF", "Monitor AXI nao encontrou a interface virtual 'vif_axi'")
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Execução: Monitorar canais de leitura e escrita em paralelo
    // -------------------------------------------------------------------------
    task run_phase(uvm_phase phase);
        // Aguarda sair do reset antes de começar a monitorar
        @(posedge vif.rst_n);

        // Dispara duas "threads" paralelas: uma vigia escritas, outra vigia leituras
        fork
            monitor_writes();
            monitor_reads();
        join
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Monitorar Transações de Escrita
    // -------------------------------------------------------------------------
    task monitor_writes();
        axi_lite_seq_item trans;
        
        forever begin
            // Cria um novo objeto para armazenar a transação capturada
            trans = axi_lite_seq_item::type_id::create("trans");
            trans.rnw = 1'b0; // Marca como Escrita (Write)

            // No AXI, os canais AW (Endereço) e W (Dado) podem acontecer
            // ao mesmo tempo ou em ordens diferentes. Monitoramos ambos em paralelo.
            fork
                begin // Vigia o Canal AW (Endereço)
                    @(posedge vif.clk iff (vif.awvalid && vif.awready));
                    trans.addr = vif.awaddr;
                end
                begin // Vigia o Canal W (Dado)
                    @(posedge vif.clk iff (vif.wvalid && vif.wready));
                    trans.data = vif.wdata;
                    trans.strb = vif.wstrb;
                end
            join

            // Vigia o Canal B (Resposta) para fechar a transação
            @(posedge vif.clk iff (vif.bvalid && vif.bready));
            trans.resp = vif.bresp;

            // Transação completa! Envia o pacote para quem estiver ouvindo (Scoreboard)
            item_collected_port.write(trans);
        end
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Monitorar Transações de Leitura
    // -------------------------------------------------------------------------
    task monitor_reads();
        axi_lite_seq_item trans;
        
        forever begin
            trans = axi_lite_seq_item::type_id::create("trans");
            trans.rnw = 1'b1; // Marca como Leitura (Read)

            // Vigia o Canal AR (Endereço de Leitura)
            @(posedge vif.clk iff (vif.arvalid && vif.arready));
            trans.addr = vif.araddr;

            // Vigia o Canal R (Dado de Leitura e Resposta)
            @(posedge vif.clk iff (vif.rvalid && vif.rready));
            trans.rdata = vif.rdata;
            trans.resp  = vif.rresp;

            // Transação completa! Transmite o pacote.
            item_collected_port.write(trans);
        end
    endtask

endclass