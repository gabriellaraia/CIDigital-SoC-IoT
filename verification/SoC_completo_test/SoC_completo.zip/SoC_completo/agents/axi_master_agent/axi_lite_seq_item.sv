// =========================================================================
// Arquivo: agents/axi_master_agent/axi_lite_seq_item.sv
// Descrição: Define a transação (pacote de dados) para o barramento AXI4-Lite.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

class axi_lite_seq_item extends uvm_sequence_item;  

    // -------------------------------------------------------------------------
    // 1. Variáveis de Estímulo (Podem ser randomizadas pelo Sequencer)
    // -------------------------------------------------------------------------
    rand bit        rnw;   // Read/Not-Write (1 = Read, 0 = Write)
    rand bit [31:0] addr;  // Endereço de destino (RAM ou Periféricos)
    rand bit [31:0] data;  // Dado a ser escrito (ignorado se for leitura)
    rand bit [3:0]  strb;  // Write strobe (quais bytes são válidos na escrita)

    // -------------------------------------------------------------------------
    // 2. Variáveis de Resposta (Preenchidas pelo Driver/Monitor)
    // -------------------------------------------------------------------------
    bit [1:0]       resp;  // Resposta do escravo (OKAY, EXOKAY, SLVERR, DECERR)
    bit [31:0]      rdata; // Dado lido do escravo (preenchido se for leitura)

    // -------------------------------------------------------------------------
    // 3. Registro na Factory do UVM (Obrigatório para automação)
    // -------------------------------------------------------------------------
    `uvm_object_utils_begin(axi_lite_seq_item)
        `uvm_field_int(rnw,   UVM_ALL_ON)
        `uvm_field_int(addr,  UVM_ALL_ON)
        `uvm_field_int(data,  UVM_ALL_ON)
        `uvm_field_int(strb,  UVM_ALL_ON)
        `uvm_field_int(resp,  UVM_ALL_ON)
        `uvm_field_int(rdata, UVM_ALL_ON)
    `uvm_object_utils_end

    // -------------------------------------------------------------------------
    // 4. Constraints Básicas (Regras de Randomização)
    // -------------------------------------------------------------------------
    constraint align_32b_c {
        addr[1:0] == 2'b00; 
    }

    // Por padrão, assumir que queremos escrever a palavra inteira
    constraint full_word_write_c {
        soft strb == 4'b1111; 
    }

    // -------------------------------------------------------------------------
    // 5. Construtor
    // -------------------------------------------------------------------------
    function new(string name = "axi_lite_seq_item");
        super.new(name);
    endfunction

endclass