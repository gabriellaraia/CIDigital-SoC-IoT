// =========================================================================
// Arquivo: agents/axi_master_agent/axi_lite_driver.sv
// Descrição: Driver UVM para o barramento AXI4-Lite (Atua como Mestre)
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

import soc_types_pkg::*; // Importa os tipos

class axi_lite_driver extends uvm_driver #(axi_lite_seq_item);
    `uvm_component_utils(axi_lite_driver)

    // Ponteiro para a interface física definida no top_hdl.sv
    virtual axi_lite_if vif;

    // Construtor padrão do UVM
    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção: Buscar a interface no banco de dados
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual axi_lite_if)::get(this, "", "vif_axi", vif)) begin
            `uvm_fatal("NO_VIF", "Driver AXI nao encontrou a interface virtual 'vif_axi'")
        end
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Execução: O loop principal do hardware virtual
    // -------------------------------------------------------------------------
    task run_phase(uvm_phase phase);
        // 1. Inicializa todos os sinais em zero (Reset)
        reset_signals();

        // 2. Aguarda o reset físico do sistema ser liberado
        @(posedge vif.rst_n);

        // 3. Loop infinito processando transações
        forever begin
            // Pega o próximo item gerado pelo Sequencer
            seq_item_port.get_next_item(req);

            // Executa a transação no barramento
            if (req.rnw == 1'b0) begin
                drive_write(req);
            end else begin
                drive_read(req);
            end

            // Avisa ao Sequencer que a transação terminou
            seq_item_port.item_done();
        end
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Resetar Sinais
    // -------------------------------------------------------------------------
    task reset_signals();
        vif.awvalid <= 1'b0;
        vif.wvalid  <= 1'b0;
        vif.bready  <= 1'b0;
        vif.arvalid <= 1'b0;
        vif.rready  <= 1'b0;
        vif.awaddr  <= '0;
        vif.wdata   <= '0;
        vif.wstrb   <= '0;
        vif.araddr  <= '0;
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Executar Escrita AXI4-Lite (Write)
    // -------------------------------------------------------------------------
    task drive_write(axi_lite_seq_item req);
        // No AXI, os canais de Endereço (AW) e Dados (W) são independentes.
        // O fork-join abaixo dispara os dois ao mesmo tempo e espera ambos terminarem.
        fork
            // Canal de Endereço de Escrita (AW)
            begin
                vif.awaddr  <= req.addr;
                vif.awvalid <= 1'b1;
                @(posedge vif.clk iff vif.awready == 1'b1);
                vif.awvalid <= 1'b0;
            end
            // Canal de Dados de Escrita (W)
            begin
                vif.wdata  <= req.data;
                vif.wstrb  <= req.strb;
                vif.wvalid <= 1'b1;
                @(posedge vif.clk iff vif.wready == 1'b1);
                vif.wvalid <= 1'b0;
            end
        join

        // Canal de Resposta (B) - Aguarda a confirmação do escravo
        vif.bready <= 1'b1;
        @(posedge vif.clk iff vif.bvalid == 1'b1);
        req.resp = vif.bresp; // Salva a resposta (ex: OKAY) de volta no pacote
        vif.bready <= 1'b0;
    endtask

    // -------------------------------------------------------------------------
    // Tarefa: Executar Leitura AXI4-Lite (Read)
    // -------------------------------------------------------------------------
    task drive_read(axi_lite_seq_item req);
        // Canal de Endereço de Leitura (AR)
        vif.araddr  <= req.addr;
        vif.arvalid <= 1'b1;
        @(posedge vif.clk iff vif.arready == 1'b1);
        vif.arvalid <= 1'b0;

        // Canal de Dados de Leitura (R) - Aguarda o dado voltar do escravo
        vif.rready <= 1'b1;
        @(posedge vif.clk iff vif.rvalid == 1'b1);
        req.rdata = vif.rdata; // Salva o dado lido de volta no pacote
        req.resp  = vif.rresp;
        vif.rready <= 1'b0;
    endtask

endclass