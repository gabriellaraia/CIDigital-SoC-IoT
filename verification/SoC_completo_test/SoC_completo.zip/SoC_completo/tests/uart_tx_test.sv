// =========================================================================
// Arquivo: tests/uart_test.sv
// Descrição: Teste focado em validar a transmissão (TX) da UART via AXI.
// =========================================================================

// -------------------------------------------------------------------------
// 1. A Sequência Virtual (O Roteiro da UART)
// -------------------------------------------------------------------------

import uvm_pkg::*;
`include "uvm_macros.svh"

class uart_tx_vseq extends uvm_sequence;
    `uvm_object_utils(uart_tx_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer) 

    function new(string name = "uart_tx_vseq");
        super.new(name);
    endfunction

    task body();
        axi_lite_seq_item axi_req;

        `uvm_info("VSEQ", "Iniciando teste de transmissao na UART...", UVM_LOW)

        // Manda o AXI escrever o caractere 'A' (Hex: 0x41) no registrador TX da UART
        `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
            rnw  == 1'b0;             // Escrita
            addr == 32'h4000_2000;    // Endereço Base da UART
            data == 32'h0000_0041;    // Payload: Letra 'A'
            strb == 4'b1111;          
        })

        `uvm_info("VSEQ", "Comando de transmissao UART enviado via AXI!", UVM_LOW)
    endtask
endclass

// -------------------------------------------------------------------------
// 2. O Teste (A Execução Principal)
// -------------------------------------------------------------------------
class uart_test extends base_test;
    `uvm_component_utils(uart_test)

    function new(string name = "uart_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
        uart_tx_vseq vseq;

        phase.raise_objection(this);
        vseq = uart_tx_vseq::type_id::create("vseq");
        
        `uvm_info("TEST", "Iniciando Sequencia da UART...", UVM_LOW)
        vseq.start(env.vsqr);

        // Como a UART é serial e depende do Baud Rate, precisamos de um 
        // delay maior aqui para dar tempo de todos os bits saírem pelo pino TX
        // antes de encerrar o teste. (Ex: 10 * tempo do bit)
        #100us; 

        phase.drop_objection(this);
    endtask
endclass