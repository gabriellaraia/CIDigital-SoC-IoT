// =========================================================================
// Arquivo: tests/soc_test_pkg.sv
// Descrição: Pacote único para Sequências e Testes do SoC.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

package soc_test_pkg;
    import uvm_pkg::*;
    `include "uvm_macros.svh"

    import soc_types_pkg::*;
    import soc_env_pkg::*;
    
    // IMPORTANTE: Importar os pacotes dos agentes para que os seq_items sejam reconhecidos
    import axi_lite_agent_pkg::*;
    import gpio_agent_pkg::*;
    import uart_agent_pkg::*;
    import spi_agent_pkg::*;
    import i2c_agent_pkg::*;

    `include "base_test.sv"
    `include "gpio_test.sv"
    `include "uart_tx_test.sv"
    `include "uart_rx_test.sv"
    `include "spi_test.sv"
    `include "i2c_test.sv"
    `include "axi_stress_vseq.sv"
    `include "interrupt_handler_vseq.sv"
endpackage