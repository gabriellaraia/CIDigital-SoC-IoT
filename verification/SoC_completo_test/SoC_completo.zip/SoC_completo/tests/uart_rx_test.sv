// =========================================================================
// Arquivo: tests/uart_rx_test.sv
// Descrição: Teste focado em validar a recepção (RX) da UART pelo AXI.
// =========================================================================

// -------------------------------------------------------------------------
// 1. A Sequência Virtual (O Roteiro Bidirecional)
// -------------------------------------------------------------------------

import uvm_pkg::*;
`include "uvm_macros.svh"

class uart_rx_vseq extends uvm_sequence;
    `uvm_object_utils(uart_rx_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer) 

    function new(string name = "uart_rx_vseq");
        super.new(name);
    endfunction

    task body();
        uart_seq_item     uart_req;
        axi_lite_seq_item axi_req;

        `uvm_info("VSEQ", "Iniciando teste de recepcao (RX) na UART...", UVM_LOW)

        // 1. Manda o Agente UART externo enviar a letra 'B' (0x42) para o pino RX do SoC
        `uvm_info("VSEQ", "Passo 1: Injetando dado serial no pino RX...", UVM_LOW)
        `uvm_do_on_with(uart_req, p_sequencer.uart_sqr, {
            data == 8'h42; 
        })

        // 2. O tempo da física: O AXI é muito rápido (clock do SoC), mas a UART 
        // é lenta (Baud Rate). Precisamos esperar os 10 bits (Start+8+Stop) 
        // terminarem de entrar no SoC antes de tentar ler.
        // Considerando 115200 bps (~8.68 us por bit) -> ~87 us totais.
        `uvm_info("VSEQ", "Passo 2: Aguardando desserializacao no hardware...", UVM_LOW)
        #100us; 

        // 3. Manda o AXI ler o registrador da UART LITE para resgatar o dado
        // (Assumindo que o offset de RX no seu IP é o endereço base 0x4000_2000. 
        // Se for outro offset, como 0x4000_2004, basta ajustar o addr abaixo).
        `uvm_info("VSEQ", "Passo 3: AXI lendo o registrador da UART...", UVM_LOW)
        `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
            rnw  == 1'b1;             // Comando de Leitura (Read)
            addr == 32'h4000_2000;    // Endereço Base da UART 
        })

        `uvm_info("VSEQ", "Teste de RX concluido pelo Maestro!", UVM_LOW)
    endtask
endclass

// -------------------------------------------------------------------------
// 2. O Teste (A Execução Principal)
// -------------------------------------------------------------------------
class uart_rx_test extends base_test;
    `uvm_component_utils(uart_rx_test)

    function new(string name = "uart_rx_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
        uart_rx_vseq vseq;

        phase.raise_objection(this);
        vseq = uart_rx_vseq::type_id::create("vseq");
        
        `uvm_info("TEST", "Iniciando Sequencia RX da UART...", UVM_LOW)
        vseq.start(env.vsqr);

        // Um pequeno delay extra para garantir que o Scoreboard processe a leitura
        #1us; 

        phase.drop_objection(this);
    endtask
endclass