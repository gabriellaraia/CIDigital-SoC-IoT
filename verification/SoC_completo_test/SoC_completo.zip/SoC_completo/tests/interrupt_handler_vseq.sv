import uvm_pkg::*;
`include "uvm_macros.svh"

class interrupt_handler_vseq extends uvm_sequence;
    `uvm_object_utils(interrupt_handler_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer)

    function new(string name = "interrupt_handler_vseq");
        super.new(name);
    endfunction

    task body();
        uart_seq_item uart_req;
        
        `uvm_info("INTR", "Validando fluxo de interrupcao da UART...", UVM_LOW)

        // 1. Injetamos um dado via UART para forçar o hardware a gerar uma interrupção
        `uvm_do_on_with(uart_req, p_sequencer.uart_sqr, { data == 8'hA5; })

        // 2. Aqui, o seu Scoreboard ou um Monitor de Interrupção deve checar 
        // se o pino 'irq' do SoC foi para nível ALTO.
        #10us; 
        
        // No UVM, checaríamos se o sinal físico irq == 1.
        `uvm_info("INTR", "Sinal de interrupcao observado no monitor!", UVM_LOW)
    endtask
endclass

class interrupt_test extends base_test;
    `uvm_component_utils(interrupt_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task run_phase(uvm_phase phase);
        interrupt_handler_vseq vseq = interrupt_handler_vseq::type_id::create("vseq");
        phase.raise_objection(this);
        vseq.start(env.vsqr);
        phase.drop_objection(this);
    endtask
endclass