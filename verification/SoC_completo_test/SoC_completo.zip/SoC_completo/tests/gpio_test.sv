// =========================================================================
// Arquivo: tests/gpio_test.sv
// Descrição: Teste focado em validar a escrita do processador nos LEDs (GPIO).
// =========================================================================

// -------------------------------------------------------------------------
// 1. A Sequência Virtual (O Roteiro do Maestro)
// -------------------------------------------------------------------------

import uvm_pkg::*;
`include "uvm_macros.svh"

class gpio_blink_vseq extends uvm_sequence;
    `uvm_object_utils(gpio_blink_vseq)
    
    // Esta macro mágica diz à sequência: "Você vai rodar dentro do soc_virtual_sequencer, 
    // então você tem acesso a todos os sequencers físicos (axi_sqr, gpio_sqr, etc) através de 'p_sequencer'"
    `uvm_declare_p_sequencer(soc_virtual_sequencer) 

    function new(string name = "gpio_blink_vseq");
        super.new(name);
    endfunction

    // A tarefa body() é onde a ação realmente acontece
    task body();
        axi_lite_seq_item axi_req;

        `uvm_info("VSEQ", "Iniciando teste de escrita no GPIO...", UVM_LOW)

        // 1. Usamos a macro `uvm_do_on_with` para criar o pacote, configurar 
        // os valores e enviá-lo pelo tubo do AXI Agent.
        `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
            rnw  == 1'b0;             // Comando de Escrita (Write)
            addr == 32'h4000_0000;    // Endereço Base do registrador GPIO
            data == 32'h0000_FFFF;    // Valor para acender metade dos 30 LEDs
            strb == 4'b1111;          // Habilita a escrita em todos os 4 bytes
        })

        `uvm_info("VSEQ", "Comando AXI enviado com sucesso!", UVM_LOW)
    endtask
endclass

// -------------------------------------------------------------------------
// 2. O Teste (A Execução Principal)
// -------------------------------------------------------------------------
class gpio_test extends base_test;
    `uvm_component_utils(gpio_test)

    function new(string name = "gpio_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    // A run_phase é a única fase que consome tempo de simulação
    task run_phase(uvm_phase phase);
        gpio_blink_vseq vseq;

        // 1. Objeção: Avisa ao simulador -> "Não feche a simulação ainda, eu tenho trabalho a fazer!"
        phase.raise_objection(this);

        // 2. Cria a sequência
        vseq = gpio_blink_vseq::type_id::create("vseq");

        `uvm_info("TEST", "Executando a Virtual Sequence no Maestro...", UVM_LOW)
        
        // 3. Dá o Play! (Inicia a sequência apontando para o Virtual Sequencer do Ambiente)
        vseq.start(env.vsqr);

        // 4. Um pequeno delay para dar tempo do sinal elétrico atravessar o seu `top_teste.v`
        // e chegar no Monitor do GPIO, que avisará o Scoreboard.
        #200ns;

        // 5. Objeção: Avisa ao simulador -> "Terminei meu roteiro. Se ninguém mais tiver trabalho, pode encerrar."
        phase.drop_objection(this);
    endtask
endclass