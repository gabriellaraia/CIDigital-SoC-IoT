// =========================================================================
// Arquivo: tests/spi_test.sv
// Descrição: Teste focado em validar a comunicação Full-Duplex do SPI.
// =========================================================================

// -------------------------------------------------------------------------
// 1. A Sequência Virtual (O Roteiro Paralelo)
// -------------------------------------------------------------------------
import uvm_pkg::*;
`include "uvm_macros.svh"

class spi_full_duplex_vseq extends uvm_sequence;
    `uvm_object_utils(spi_full_duplex_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer) 

    function new(string name = "spi_full_duplex_vseq");
        super.new(name);
    endfunction

    task body();
        spi_seq_item      spi_req;
        axi_lite_seq_item axi_req;

        `uvm_info("VSEQ", "Iniciando teste Full-Duplex do SPI...", UVM_LOW)

        // O bloco fork...join executa as threads internas simultaneamente.
        // O código só continua quando ambas as threads terminarem.
        fork
            // -----------------------------------------------------------------
            // THREAD 1: O Mundo Externo (Agente SPI Escravo)
            // -----------------------------------------------------------------
            begin
                // Preparamos o Agente para que, quando o Chip Select (ss_n) cair,
                // ele responda enviando o dado 0x88 (10001000) no pino MISO.
                `uvm_info("VSEQ", "Armando o Agente SPI com a resposta 0x88...", UVM_LOW)
                `uvm_do_on_with(spi_req, p_sequencer.spi_sqr, {
                    data_miso == 8'h88; 
                })
            end

            // -----------------------------------------------------------------
            // THREAD 2: O Mundo Interno (Processador / AXI)
            // -----------------------------------------------------------------
            begin
                // Damos um micro-atraso de 10ns apenas para garantir que a Thread 1 
                // já engatilhou o agente escravo antes do SoC começar a agir.
                #10ns; 
                
                // O Processador escreve o padrão 0xAA (10101010) no registrador TX 
                // do SPI (Assumindo base 0x4000_3000). Isso fará o hardware do SoC 
                // abaixar o ss_n, gerar o clock e cuspir 0xAA no pino MOSI.
                `uvm_info("VSEQ", "AXI comandando envio de 0xAA no MOSI...", UVM_LOW)
                `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
                    rnw  == 1'b0;             
                    addr == 32'h4000_3000;    
                    data == 32'h0000_00AA;    
                    strb == 4'b1111;
                })
            end
        join

        // Aguardamos o tempo físico da transmissão serial (depende do divisor 
        // de clock do seu SPI, mas 10us geralmente é seguro para a maioria).
        #10us;
        
        // (Opcional) Aqui, num teste avançado, mandaríamos o AXI ler o registrador 
        // RX do SPI para garantir que o SoC recebeu o 0x88 que o nosso agente mandou.

        `uvm_info("VSEQ", "Teste SPI concluido com sucesso pelo Maestro!", UVM_LOW)
    endtask
endclass

// -------------------------------------------------------------------------
// 2. O Teste (A Execução Principal)
// -------------------------------------------------------------------------
class spi_test extends base_test;
    `uvm_component_utils(spi_test)

    function new(string name = "spi_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
        spi_full_duplex_vseq vseq;

        phase.raise_objection(this);
        vseq = spi_full_duplex_vseq::type_id::create("vseq");
        
        `uvm_info("TEST", "Iniciando Sequencia do SPI...", UVM_LOW)
        vseq.start(env.vsqr);

        phase.drop_objection(this);
    endtask
endclass