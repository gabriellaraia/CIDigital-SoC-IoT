import uvm_pkg::*;
`include "uvm_macros.svh"

class axi_stress_vseq extends uvm_sequence;
    `uvm_object_utils(axi_stress_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer)

    function new(string name = "axi_stress_vseq");
        super.new(name);
    endfunction

    task body();
        axi_lite_seq_item axi_req;
        bit [31:0] target_addrs[] = '{32'h4000_0000, 32'h4000_2000, 32'h4000_3000, 32'h4000_4000};

        `uvm_info("STRESS", "Iniciando Teste de Carga no Barramento AXI...", UVM_LOW)

        // Dispara 50 transações aleatórias para os periféricos
        repeat(50) begin
            `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
                addr inside {target_addrs}; // Escolhe um periférico aleatório
                data == $urandom;          // Dado aleatório
                rnw  == $urandom_range(0,1); // Leitura ou Escrita aleatória
            })
        end
    endtask
endclass

class axi_stress_test extends base_test;
    `uvm_component_utils(axi_stress_test)
    function new(string name, uvm_component parent); super.new(name, parent); endfunction

    task run_phase(uvm_phase phase);
        axi_stress_vseq vseq = axi_stress_vseq::type_id::create("vseq");
        phase.raise_objection(this);
        vseq.start(env.vsqr);
        phase.drop_objection(this);
    endtask
endclass