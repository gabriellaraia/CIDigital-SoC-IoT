// =========================================================================
// Arquivo: tests/base_test.sv
// Descrição: Teste base do SoC. Instancia o ambiente e configura o padrão.
//            Todos os testes reais herdarão desta classe.
// =========================================================================
import uvm_pkg::*;
`include "uvm_macros.svh"

class base_test extends uvm_test;
    // Registro na Factory do UVM
    `uvm_component_utils(base_test)

    // Instância do nosso Ambiente (a placa-mãe que acabamos de criar)
    soc_env env;

    // Construtor padrão
    function new(string name = "base_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Construção (Build Phase)
    // -------------------------------------------------------------------------
    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        
        // Cria o ambiente usando a Factory
        env = soc_env::type_id::create("env", this);
        
        // Opcional: Aqui poderíamos configurar variáveis globais usando o 
        // uvm_config_db antes dos agentes serem criados.
    endfunction

    // -------------------------------------------------------------------------
    // Fase de Relatório (Report Phase)
    // -------------------------------------------------------------------------
    function void report_phase(uvm_phase phase);
        uvm_report_server server;
        int err_num;
        
        super.report_phase(phase);
        server = uvm_report_server::get_server();
        err_num = server.get_severity_count(UVM_ERROR) + server.get_severity_count(UVM_FATAL);

        // Imprime um banner bonito no final da simulação
        if (err_num == 0) begin
            `uvm_info("STATUS", "\n---------------------------------------------------\n--- TESTE PASSOU COM SUCESSO! ZERO ERROS! ---\n---------------------------------------------------", UVM_NONE)
        end else begin
            `uvm_error("STATUS", $sformatf("\n---------------------------------------------------\n--- TESTE FALHOU! ENCONTRADOS %0d ERROS! ---\n---------------------------------------------------", err_num))
        end
    endfunction

endclass