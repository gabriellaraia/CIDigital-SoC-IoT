// =========================================================================
// Arquivo: tests/i2c_test.sv
// Descrição: Teste focado em validar uma transação de escrita I2C (Mestre -> Escravo).
// =========================================================================

// -------------------------------------------------------------------------
// 1. A Sequência Virtual (O Roteiro Paralelo)
// -------------------------------------------------------------------------
import uvm_pkg::*;
`include "uvm_macros.svh"

class i2c_master_write_vseq extends uvm_sequence;
    `uvm_object_utils(i2c_master_write_vseq)
    `uvm_declare_p_sequencer(soc_virtual_sequencer) 

    function new(string name = "i2c_master_write_vseq");
        super.new(name);
    endfunction

    task body();
        i2c_seq_item      i2c_req;
        axi_lite_seq_item axi_req;

        `uvm_info("VSEQ", "Iniciando teste de Escrita (Master Write) no I2C...", UVM_LOW)

        fork
            // -----------------------------------------------------------------
            // THREAD 1: O Mundo Externo (Agente I2C Escravo)
            // -----------------------------------------------------------------
            begin
                `uvm_info("VSEQ", "Armando o Agente I2C Escravo para esperar uma transacao...", UVM_LOW)
                // O escravo fica travado aqui esperando um START, seguido do endereço 0x5A.
                // Como é uma escrita do mestre, o escravo apenas receberá o dado.
                `uvm_do_on(i2c_req, p_sequencer.i2c_sqr)
            end

            // -----------------------------------------------------------------
            // THREAD 2: O Mundo Interno (Processador / AXI)
            // -----------------------------------------------------------------
            begin
                // Atraso de segurança para garantir que a Thread 1 já armou o Escravo
                #10ns; 
                
                // Nota: O fluxo exato de registradores depende do design do seu `i2c_master_axil`.
                // Geralmente, precisamos escrever o Endereço do Escravo + bit R/W em um registrador,
                // o Dado em outro, e o Comando de START em um terceiro.
                // Aqui abstraímos para uma única escrita representativa no endereço base.
                
                `uvm_info("VSEQ", "AXI comandando o SoC a escrever 0xEE no Escravo 0x5A...", UVM_LOW)
                `uvm_do_on_with(axi_req, p_sequencer.axi_sqr, {
                    rnw  == 1'b0;             
                    addr == 32'h4000_4000;    // Endereço Base do bloco I2C no SoC
                    data == 32'h0000_00EE;    // Payload (Ex: 0xEE)
                    strb == 4'b1111;
                })
            end
        join

        // Aguarda o tempo físico da transmissão I2C (ex: 100kbps ou 400kbps leva um certo tempo)
        // Um byte + endereço + ACKs a 100kHz leva aproximadamente 200us.
        #250us;

        // Ao final, o monitor I2C terá capturado toda a transação nos pinos SDA/SCL 
        // e mandado para o Scoreboard conferir se o 0xEE realmente viajou pelo fio!

        `uvm_info("VSEQ", "Teste I2C concluido pelo Maestro!", UVM_LOW)
    endtask
endclass

// -------------------------------------------------------------------------
// 2. O Teste (A Execução Principal)
// -------------------------------------------------------------------------
class i2c_test extends base_test;
    `uvm_component_utils(i2c_test)

    function new(string name = "i2c_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    task run_phase(uvm_phase phase);
        i2c_master_write_vseq vseq;

        phase.raise_objection(this);
        vseq = i2c_master_write_vseq::type_id::create("vseq");
        
        `uvm_info("TEST", "Iniciando Sequencia do I2C...", UVM_LOW)
        vseq.start(env.vsqr);

        phase.drop_objection(this);
    endtask
endclass