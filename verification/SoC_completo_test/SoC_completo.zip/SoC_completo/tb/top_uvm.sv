// =========================================================================
// Arquivo: tb/top_uvm.sv
// Descrição: Super Wrapper para resolver dependências no Vivado (XSim)
// =========================================================================

// 1. Bibliotecas Base
import uvm_pkg::*;
`include "uvm_macros.svh"
import soc_test_pkg::*; 

module top_uvm;

    // O Vivado precisa de um ponto de entrada para o simulador
    initial begin
        run_test();
    end

endmodule