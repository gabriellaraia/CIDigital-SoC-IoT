// =========================================================================
// Arquivo: tb/top_hdl.sv
// Descrição: Top Level de Hardware (Estático). Instancia o DUT, as
//            interfaces e as armazena no uvm_config_db.
// =========================================================================

import uvm_pkg::*;
import soc_types_pkg::*; // <-- Mova isto para o TOPO

`include "uvm_macros.svh"

module top_hdl;

    // -------------------------------------------------------------------------
    // 1. Geração de Clock e Reset
    // -------------------------------------------------------------------------
    logic clk;
    logic rst_n;

    initial begin
        clk = 0;
        forever #5 clk = ~clk; // Clock de 100MHz (Período de 10ns)
    end

    initial begin
        rst_n = 0;
        #50 rst_n = 1; // Libera o reset após 50ns
    end

    // -------------------------------------------------------------------------
    // 2. Instanciação das Interfaces
    // -------------------------------------------------------------------------
    // AXI4-Lite (Usado pelo VIP para substituir a CPU)
    axi_lite_if #(32, 32) vif_axi(.clk(clk), .rst_n(rst_n));

    // Periféricos
    gpio_if  #(5, 30) vif_gpio(.clk(clk));
    uart_if           vif_uart();
    spi_if   #(1)     vif_spi();
    i2c_if            vif_i2c();
    intr_if           vif_intr();

    // -------------------------------------------------------------------------
    // 3. Instanciação do Design Under Test (DUT)
    // -------------------------------------------------------------------------
    soc_top_teste_mem_periph #(
        .ADDR_WIDTH(32),
        .DATA_WIDTH(32),
        .RAM_BYTES_REQ(64*1024),
        .REG_COUNT_PER_PORT(64) 
    ) dut (
        .aclk       (clk), 
        .aresetn    (rst_n), 
        
        // UART
        .uart_rx    (vif_uart.rx), 
        .uart_tx    (vif_uart.tx), 
        
        // GPIO
        .gpio_i     (vif_gpio.gpio_i), 
        .gpio_o     (vif_gpio.gpio_o), 
        
        // SPI
        .spi_sclk_o (vif_spi.sclk), 
        .spi_mosi_o (vif_spi.mosi), 
        .spi_miso_i (vif_spi.miso), 
        .spi_ss_n_o (vif_spi.ss_n), 
        
        // I2C
        .i2c_sda    (vif_i2c.sda), 
        .i2c_scl    (vif_i2c.scl), 
        
        // Debug/Trap
        .trap       (vif_intr.trap) 
    );

    // Conectando sinais internos à interface de interrupção usando referência hierárquica
    assign vif_intr.cpu_global_irq = dut.cpu_global_irq; 

    // -------------------------------------------------------------------------
    // 4. Lógica de Bypass do Núcleo (Fase de Estresse de Barramento)
    // -------------------------------------------------------------------------
    // Se a macro UVM_AXI_VIP estiver definida durante a compilação, 
    // forçamos os sinais do barramento AXI (saindo do PicoRV32) a receberem
    // os valores gerados pelo nosso AXI Master UVC.
    `ifdef UVM_AXI_VIP
        // O FORCE fica DENTRO do initial
        initial begin
            force dut.cpu_awvalid = vif_axi.awvalid; 
            force dut.cpu_awaddr  = vif_axi.awaddr; 
            force dut.cpu_awprot  = vif_axi.awprot; 
            force dut.cpu_wvalid  = vif_axi.wvalid; 
            force dut.cpu_wdata   = vif_axi.wdata; 
            force dut.cpu_wstrb   = vif_axi.wstrb; 
            force dut.cpu_bready  = vif_axi.bready; 
            force dut.cpu_arvalid = vif_axi.arvalid; 
            force dut.cpu_araddr  = vif_axi.araddr; 
            force dut.cpu_arprot  = vif_axi.arprot; 
            force dut.cpu_rready  = vif_axi.rready; 
        end

        // O ASSIGN fica FORA do initial (direto no module)
        assign vif_axi.awready = dut.cpu_awready; 
        assign vif_axi.wready  = dut.cpu_wready; 
        assign vif_axi.bvalid  = dut.cpu_bvalid; 
        assign vif_axi.bresp   = dut.u_root_ic.m_bresp; 
        assign vif_axi.arready = dut.cpu_arready; 
        assign vif_axi.rvalid  = dut.cpu_rvalid; 
        assign vif_axi.rdata   = dut.cpu_rdata; 
        assign vif_axi.rresp   = dut.u_root_ic.m_rresp; 
    `endif

    // -------------------------------------------------------------------------
    // 5. Registro no Config DB para o UVM (Mundo Dinâmico)
    // -------------------------------------------------------------------------

    initial begin
        // O formato é: uvm_config_db#(virtual interface_tipo)::set(contexto, caminho_instancia, nome_string, ponteiro_interface);
        
        // Usando os novos tipos do soc_types_pkg para garantir compatibilidade com Drivers/Monitors
        uvm_config_db#(v_axi_if_t)::set(null, "*", "vif_axi", vif_axi);
        uvm_config_db#(v_gpio_if_t)::set(null, "*", "vif_gpio", vif_gpio);
        uvm_config_db#(v_uart_if_t)::set(null, "*", "vif_uart", vif_uart);
        uvm_config_db#(v_spi_if_t)::set(null, "*", "vif_spi", vif_spi);
        uvm_config_db#(v_i2c_if_t)::set(null, "*", "vif_i2c", vif_i2c);
        uvm_config_db#(v_intr_if_t)::set(null, "*", "vif_intr", vif_intr);
    end

endmodule