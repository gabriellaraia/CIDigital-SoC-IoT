package soc_types_pkg;
    // Forward declarations para o Vivado não se perder
    typedef virtual axi_lite_if v_axi_if_t_temp; 
    
    // Suas definições reais
    typedef virtual axi_lite_if #(32, 32) v_axi_if_t;
    typedef virtual gpio_if #(5, 30)      v_gpio_if_t;
    typedef virtual spi_if #(1)           v_spi_if_t;
    typedef virtual uart_if               v_uart_if_t;
    typedef virtual i2c_if                v_i2c_if_t;
    typedef virtual intr_if               v_intr_if_t;
endpackage