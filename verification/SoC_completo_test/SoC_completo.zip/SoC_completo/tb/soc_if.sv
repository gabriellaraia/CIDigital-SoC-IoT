// =========================================================================
// Arquivo: tb/soc_if.sv
// Descrição: Definição de todas as interfaces físicas para o SoC PicoRV32
// =========================================================================

// -------------------------------------------------------------------------
// 1. Interface do Barramento AXI4-Lite (Master/Monitor)
// Usada para substituir o PicoRV32 e testar o u_root_ic diretamente.
// -------------------------------------------------------------------------
interface axi_lite_if #(
    parameter integer ADDR_WIDTH = 32,
    parameter integer DATA_WIDTH = 32
)(
    input logic clk,
    input logic rst_n
);
    // Canal de Endereço de Escrita (AW)
    logic [ADDR_WIDTH-1:0] awaddr;
    logic [2:0]            awprot;
    logic                  awvalid;
    logic                  awready;

    // Canal de Dados de Escrita (W)
    logic [DATA_WIDTH-1:0] wdata;
    logic [(DATA_WIDTH/8)-1:0] wstrb;
    logic                  wvalid;
    logic                  wready;

    // Canal de Resposta de Escrita (B)
    logic [1:0]            bresp;
    logic                  bvalid;
    logic                  bready;

    // Canal de Endereço de Leitura (AR)
    logic [ADDR_WIDTH-1:0] araddr;
    logic [2:0]            arprot;
    logic                  arvalid;
    logic                  arready;

    // Canal de Dados de Leitura (R)
    logic [DATA_WIDTH-1:0] rdata;
    logic [1:0]            rresp;
    logic                  rvalid;
    logic                  rready;
endinterface

// -------------------------------------------------------------------------
// 2. Interface GPIO
// Mapeia as 5 entradas e 30 saídas do bloco u_gpio.
// -------------------------------------------------------------------------
interface gpio_if #(
    parameter integer NIN = 5,
    parameter integer NOUT = 30
)(
    input logic clk // Adicionado o sinal de clock
);
    logic [NIN-1:0]  gpio_i; 
    logic [NOUT-1:0] gpio_o; 
endinterface

// -------------------------------------------------------------------------
// 3. Interface UART
// -------------------------------------------------------------------------
interface uart_if;
    logic rx;
    logic tx;
endinterface

// -------------------------------------------------------------------------
// 4. Interface SPI
// Mapeia sclk, mosi, miso e o vetor de chip select.
// -------------------------------------------------------------------------
interface spi_if #(
    parameter integer NUM_SS_BITS = 1
);
    logic                   sclk;
    logic                   mosi;
    logic                   miso;
    logic [NUM_SS_BITS-1:0] ss_n;
endinterface

// -------------------------------------------------------------------------
// 5. Interface I2C (Sinais Tri-State)
// -------------------------------------------------------------------------
interface i2c_if;
    logic scl; // Declarado como wire por ser inout
    logic sda; // Declarado como wire por ser inout
endinterface

// -------------------------------------------------------------------------
// 6. Interface de Interrupção e Status (Sinais Internos e Debug)
// Monitora a saída do axil_intc e sinais de falha do processador.
// -------------------------------------------------------------------------
interface intr_if;
    logic       cpu_global_irq; // Sinal que vai para a CPU
    logic       trap;           // Sinal de falha/exceção do PicoRV32
    logic [7:0] irq_sources;    // Vetor interno de interrupções (opcional, para debug avançado)
endinterface