`timescale 1ns/1ps

module tb_soc_i2c;

////////////////////////////////////////////////////////////
// CLOCK / RESET
////////////////////////////////////////////////////////////
reg aclk = 0;
reg aresetn = 0;

always #5 aclk = ~aclk;   // 100 MHz

initial begin
    #100;
    aresetn = 1;
end

////////////////////////////////////////////////////////////
// ENTRADAS DO SOC
////////////////////////////////////////////////////////////
reg boot_pin = 0;

reg uart_rx = 1;
reg spi_miso = 0;
reg spi_miso_i = 0;

reg [4:0] gpio_i = 0;

////////////////////////////////////////////////////////////
// WIRES DO SOC
////////////////////////////////////////////////////////////
wire spi_csn;
wire spi_sclk;
wire spi_mosi;

wire uart_tx;

wire [29:0] gpio_o;

wire spi_sclk_o;
wire spi_mosi_o;
wire spi_ss_n_o;

wire i2c_sda;
wire i2c_scl;

wire trap;

////////////////////////////////////////////////////////////
// DUT
////////////////////////////////////////////////////////////
soc_top dut (
    .aclk(aclk),
    .aresetn(aresetn),
    .boot_pin(boot_pin),

    .spi_csn(spi_csn),
    .spi_sclk(spi_sclk),
    .spi_mosi(spi_mosi),
    .spi_miso(spi_miso),

    .uart_rx(uart_rx),
    .uart_tx(uart_tx),

    .gpio_i(gpio_i),
    .gpio_o(gpio_o),

    .spi_sclk_o(spi_sclk_o),
    .spi_mosi_o(spi_mosi_o),
    .spi_miso_i(spi_miso_i),
    .spi_ss_n_o(spi_ss_n_o),

    .i2c_sda(i2c_sda),
    .i2c_scl(i2c_scl),

    .trap(trap)
);

////////////////////////////////////////////////////////////
// PULLUPS I2C (IMPORTANTE PARA OPEN-DRAIN)
////////////////////////////////////////////////////////////
pullup(i2c_sda);
pullup(i2c_scl);

////////////////////////////////////////////////////////////
// TIMEOUT
////////////////////////////////////////////////////////////
initial begin
    #5_000_000;
    $display("TIMEOUT - encerrando simulação");
    $finish;
end

////////////////////////////////////////////////////////////
// DUMP VCD
////////////////////////////////////////////////////////////
/*
initial begin
    $dumpfile("soc_i2c.vcd");
    $dumpvars(0, tb_soc_i2c);
end
*/

always @(posedge aclk) begin
    if (dut.cpu_awvalid)
        $display("[%0t] CPU tentando escrever em %h", $time, dut.cpu_awaddr);
end

initial begin
    wait(aresetn == 1);
    #1000;
    if (dut.trap)
        $display("CPU entrou em TRAP!");
    else
        $display("CPU aparentemente rodando.");
end

////////////////////////////////////////////////////////////
// MONITOR AXI WRITES PARA REGIÃO I2C (0x4000_4000)
////////////////////////////////////////////////////////////
/*
always @(posedge aclk) begin
    if (dut.cpu_awvalid && dut.cpu_awready &&
        dut.cpu_wvalid  && dut.cpu_wready) begin

        if ((dut.cpu_awaddr & 32'hFFFF_F000) == 32'h4000_4000) begin
            $display("[%0t] AXI WRITE I2C ADDR=%h DATA=%h",
                     $time,
                     dut.cpu_awaddr,
                     dut.cpu_wdata);
        end
    end
end
*/
always @(posedge aclk) begin
    if (dut.cpu_awvalid && dut.cpu_awready) begin
        $display("[%0t] AXI WRITE ADDR=%h DATA=%h",
                 $time,
                 dut.cpu_awaddr,
                 dut.cpu_wdata);
    end
end

////////////////////////////////////////////////////////////
// MONITOR I2C START / STOP (Solução A)
////////////////////////////////////////////////////////////
reg sda_d;

always @(posedge aclk) begin
    sda_d <= i2c_sda;

    // START: SDA cai com SCL alto
    if (sda_d === 1'b1 &&
        i2c_sda === 1'b0 &&
        i2c_scl === 1'b1) begin

        $display("[%0t] I2C START", $time);
    end

    // STOP: SDA sobe com SCL alto
    if (sda_d === 1'b0 &&
        i2c_sda === 1'b1 &&
        i2c_scl === 1'b1) begin

        $display("[%0t] I2C STOP", $time);
    end
end

////////////////////////////////////////////////////////////
// MONITOR BYTES I2C
////////////////////////////////////////////////////////////
reg [2:0] bit_cnt = 0;
reg [7:0] shift_reg = 0;

always @(posedge i2c_scl) begin
    if (i2c_sda !== 1'bz) begin
        shift_reg <= {shift_reg[6:0], i2c_sda};
        bit_cnt <= bit_cnt + 1;

        if (bit_cnt == 3'd7) begin
            $display("[%0t] I2C BYTE = %02h",
                     $time,
                     {shift_reg[6:0], i2c_sda});
            bit_cnt <= 0;
        end
    end
end

////////////////////////////////////////////////////////////
// FINALIZA AUTOMATICAMENTE APÓS STOP
////////////////////////////////////////////////////////////
reg stop_seen = 0;

always @(posedge aclk) begin
    if (!stop_seen &&
        i2c_scl === 1'b1 &&
        sda_d === 1'b0 &&
        i2c_sda === 1'b1) begin

        stop_seen <= 1;
        $display("I2C transaction complete.");
        #1000;
        $finish;
    end
end

endmodule