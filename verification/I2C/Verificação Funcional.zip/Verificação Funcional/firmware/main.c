#include <stdint.h>

#define I2C_BASE        0x40004000

#define I2C_PRESCALE    (*(volatile uint32_t*)(I2C_BASE + 0x00))
#define I2C_CONTROL     (*(volatile uint32_t*)(I2C_BASE + 0x04))
#define I2C_STATUS      (*(volatile uint32_t*)(I2C_BASE + 0x08))
#define I2C_COMMAND     (*(volatile uint32_t*)(I2C_BASE + 0x0C))
#define I2C_DATA        (*(volatile uint32_t*)(I2C_BASE + 0x10))

#define CTRL_ENABLE     (1 << 0)

#define CMD_START   (1 << 0)
#define CMD_STOP    (1 << 1)
#define CMD_WRITE   (1 << 2)
#define CMD_READ    (1 << 3)

static void delay(int d)
{
    for (volatile int i = 0; i < d; i++);
}

static void wait_busy()
{
    while (I2C_STATUS & (1 << 0)); // busy bit
}

void main()
{
    // 1. Configura prescale (clock mais lento para simulação)
    I2C_PRESCALE = 100;

    // 2. Habilita I2C
    I2C_CONTROL = CTRL_ENABLE;

    delay(1000);

    // START + endereço 0x50 write (0xA0)
    I2C_DATA = 0xA0;
    I2C_COMMAND = CMD_START | CMD_WRITE;
    wait_busy();

    // Envia 0xAA
    I2C_DATA = 0xAA;
    I2C_COMMAND = CMD_WRITE;
    wait_busy();

    // Envia 0x55
    I2C_DATA = 0x55;
    I2C_COMMAND = CMD_WRITE;
    wait_busy();

    // STOP
    I2C_COMMAND = CMD_STOP;
    wait_busy();

    while (1);
}