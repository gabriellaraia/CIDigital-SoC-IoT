#include <stdint.h>

#define TIMER_BASE  0x40001000
#define INTC_BASE   0x40005000

// TIMER
#define T_CTRL      (*(volatile uint32_t*)(TIMER_BASE + 0x08))
#define T_CMP       (*(volatile uint32_t*)(TIMER_BASE + 0x0C))
#define T_VAL       (*(volatile uint32_t*)(TIMER_BASE + 0x10))
#define T_PRESC     (*(volatile uint32_t*)(TIMER_BASE + 0x20))
#define T_STATUS    (*(volatile uint32_t*)(TIMER_BASE + 0x28))

// INTC
#define INTC_ISR    (*(volatile uint32_t*)(INTC_BASE + 0x00))
#define INTC_IER    (*(volatile uint32_t*)(INTC_BASE + 0x08))
#define INTC_IAR    (*(volatile uint32_t*)(INTC_BASE + 0x0C))
#define INTC_MER    (*(volatile uint32_t*)(INTC_BASE + 0x10))

void irq_handler(void)
{
    // Clear timer flag
    T_STATUS = 0x2;

    // Ack interrupt controller (bit 1 = timer)
    INTC_IAR = (1 << 1);
}

int main(void)
{
    // Disable timer
    T_CTRL = 0;

    // 500 us @100MHz
    T_PRESC = 100;
    T_VAL   = 0;
    T_CMP   = 499;

    T_STATUS = 0x3;

    T_CTRL = (1<<1) | (1<<2) | (1<<3);

    // Enable timer interrupt in INTC
    INTC_IER = (1 << 1);

    // Master enable
    INTC_MER = 0x3;

    while (1)
        ;

    return 0;
}