`timescale 1ns/1ps
`default_nettype none

module tb_soc_timer;

reg clk = 0;
always #5 clk = ~clk;   // 100 MHz

reg aresetn = 0;

initial begin
    #100;
    aresetn = 1;
end

wire trap;

soc_top #(
    .RAM_BYTES_REQ(64*1024)
) dut (
    .aclk(clk),
    .aresetn(aresetn),
    .boot_pin(1'b0),

    .spi_csn(),
    .spi_sclk(),
    .spi_mosi(),
    .spi_miso(1'b0),

    .uart_rx(1'b1),
    .uart_tx(),

    .gpio_i(5'b0),
    .gpio_o(),

    .spi_sclk_o(),
    .spi_mosi_o(),
    .spi_miso_i(1'b0),
    .spi_ss_n_o(),

    .i2c_sda(),
    .i2c_scl(),

    .trap(trap)
);

////////////////////////////////////////////////////////////
// MONITOR AXI WRITES (CPU)
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (dut.cpu_awvalid && dut.cpu_awready)
        $display("[%0t] AW handshake! addr=%h",
                 $time, dut.cpu_awaddr);
end

////////////////////////////////////////////////////////////
// MONITOR TIMER IRQ
////////////////////////////////////////////////////////////
reg timer_irq_d = 0;
integer irq_count = 0;

always @(posedge clk) begin
    timer_irq_d <= dut.timer_irq;

    if (dut.timer_irq && !timer_irq_d) begin
        irq_count = irq_count + 1;

        $display("------------------------------------------------");
        $display("[%0t ps] TIMER IRQ RAW (%0d)",
                 $time,
                 irq_count);
        $display("Timer value = %d",
                 dut.u_timer.timer0_value_q);
        $display("------------------------------------------------");
    end
end

////////////////////////////////////////////////////////////
// MONITOR INTC OUTPUT
////////////////////////////////////////////////////////////
reg global_irq_d = 0;

always @(posedge clk) begin
    global_irq_d <= dut.cpu_global_irq;

    if (dut.cpu_global_irq && !global_irq_d) begin
        $display("[%0t ns] CPU GLOBAL IRQ ASSERTED", $time);
    end
end

always @(posedge clk) begin
    if (dut.cpu_global_irq)
        $display("[%0t] GLOBAL IRQ HIGH", $time);
end

////////////////////////////////////////////////////////////
// MONITOR TRAP
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (trap) begin
        $display("CPU entrou em TRAP!");
        $stop;
    end
end

////////////////////////////////////////////////////////////
// STOP AFTER SOME TIME
////////////////////////////////////////////////////////////
initial begin
    #3_000_000; // 3 ms
    $display("Simulation finished.");
    $stop;
end

endmodule