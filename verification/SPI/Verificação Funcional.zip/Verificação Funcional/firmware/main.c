#include <stdint.h>

#define SPI_BASE        0x40003000

#define SPI_ID      (*(volatile uint32_t*)(SPI_BASE + 0x00))
#define SPI_CTRL    (*(volatile uint32_t*)(SPI_BASE + 0x20))
#define SPI_STATUS  (*(volatile uint32_t*)(SPI_BASE + 0x28))
#define SPI_SS      (*(volatile uint32_t*)(SPI_BASE + 0x2C))
#define SPI_TX      (*(volatile uint32_t*)(SPI_BASE + 0x30))
#define SPI_RX      (*(volatile uint32_t*)(SPI_BASE + 0x34))

#define SPI_CTRL_SPE    (1 << 1)

/*
int main()
{
    volatile uint32_t tmp;

    // Lê ID (testa leitura AXI)
    tmp = SPI_ID;

    // Habilita SPI
    SPI_CTRL = SPI_CTRL_SPE;

    // Ativa slave 0 (ativo baixo)
    SPI_SS = 0x0;

    // Escreve dado
    SPI_TX = 0xA5;

    // Pequeno delay
    for (volatile int i = 0; i < 1000; i++);

    // Lê RX (mesmo que vazio, só para testar AXI read)
    tmp = SPI_RX;

    while (1);
}
*/

#include <stdint.h>

int main()
{
    volatile uint32_t *reg = (uint32_t*)0x40003000;

    *reg = 0xDEADBEEF;

    while (1);
}