`timescale 1ns/10ps
`default_nettype none

module tb_soc_gpio;

reg clk;
reg aresetn;
reg boot_pin;

// GPIO
reg  [4:0]  gpio_i;
wire [29:0] gpio_o;

// SPI EEPROM (não usado)
wire spi_csn;
wire spi_sclk;
wire spi_mosi;
reg  spi_miso = 1'b0;

// UART (não usado)
reg  uart_rx = 1'b1;
wire uart_tx;

// SPI master (não usado)
wire spi_sclk_o;
wire spi_mosi_o;
reg  spi_miso_i = 1'b0;
wire spi_ss_n_o;

// I2C (não usado)
wire i2c_sda;
wire i2c_scl;

// Debug
wire trap;

////////////////////////////////////////////////////////////
// Clock 100 MHz
////////////////////////////////////////////////////////////
initial clk = 0;
always #5 clk = ~clk;

////////////////////////////////////////////////////////////
// DUT
////////////////////////////////////////////////////////////
soc_top #(
    .RAM_BYTES_REQ(64*1024)
) dut (
    .aclk(clk),
    .aresetn(aresetn),

    .boot_pin(boot_pin),

    .spi_csn(spi_csn),
    .spi_sclk(spi_sclk),
    .spi_mosi(spi_mosi),
    .spi_miso(spi_miso),

    .uart_rx(uart_rx),
    .uart_tx(uart_tx),

    .gpio_i(gpio_i),
    .gpio_o(gpio_o),

    .spi_sclk_o(spi_sclk_o),
    .spi_mosi_o(spi_mosi_o),
    .spi_miso_i(spi_miso_i),
    .spi_ss_n_o(spi_ss_n_o),

    .i2c_sda(i2c_sda),
    .i2c_scl(i2c_scl),

    .trap(trap)
);

////////////////////////////////////////////////////////////
// Reset e estímulos
////////////////////////////////////////////////////////////
initial begin
    $display("=================================");
    $display("   TESTE CPU + GPIO INICIADO");
    $display("=================================");

    gpio_i   = 5'b00000;
    boot_pin = 1'b0;  // <<< DESABILITA BOOT
    aresetn  = 1'b0;

    #100;
    aresetn = 1'b1;
end

////////////////////////////////////////////////////////////
// Monitor de escrita no GPIO
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (aresetn) begin

        // Se firmware escrever este valor -> PASS
        if (gpio_o == 30'h15555555) begin
            $display("===== TEST PASS =====");
            $stop;
        end
        // Se escrever este valor -> FAIL 
        else if (gpio_o == 30'h3BBBBBBB) begin
            $display("===== TEST FAIL =====");
            $stop;
        end
    end
end

////////////////////////////////////////////////////////////
// Debug
////////////////////////////////////////////////////////////
always @(posedge clk) begin
    if (dut.cpu_awvalid && dut.cpu_awready &&
        dut.cpu_wvalid  && dut.cpu_wready) begin
        $display("CPU WRITE: ADDR=%h DATA=%h STRB=%h",
                  dut.cpu_awaddr,
                  dut.cpu_wdata,
                  dut.cpu_wstrb);
    end
end

////////////////////////////////////////////////////////////
// Timeout
////////////////////////////////////////////////////////////
initial begin
    #10_000_000;
    $display("===== TIMEOUT =====");
    $stop;
end

endmodule