#include <stdint.h>

#define GPIO_BASE 0x40000000
#define GPIO_OUT  (*(volatile uint32_t*)(GPIO_BASE + 0x00))
#define GPIO_IN   (*(volatile uint32_t*)(GPIO_BASE + 0x04))

int main()
{
    GPIO_OUT = 0x55555555;

    uint32_t read_out = GPIO_IN;

    if (read_out == 0x55555555)
    {
        GPIO_OUT = 0xAAAAAAAA;
    }
    else
    {
        GPIO_OUT = 0xBBBBBBBB;
    }
    
    while (1) {

    }
}